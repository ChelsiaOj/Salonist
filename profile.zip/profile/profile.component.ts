import { Component, OnInit } from '@angular/core';
import { checkAndUpdateBinding } from '@angular/core/src/view/util';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  
user:any;
check:boolean=true;
  constructor() {

  
    this.user=
    {
      name:"Sandra Tom",    
    job:"Teacher",
    address:"Iritty Kannur",
    phone:['8281177379']
    };
    
   }


   togglecheck(){

    this.check=!this.check;
   }
   
  ngOnInit() {
  }

}
