<?php
if(isset($_GET['btn']))
{
$name=$_GET['name'];
$mail=$_GET['id'];
echo "$name";

echo "$mail";
}
?>