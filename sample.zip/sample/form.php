<html>
<form action="form2.php" method="GET">
Name:<input type="text" name="name"><br><br>
Email:<input type="text" name="id"><br>
<input type="submit" value="Submit" name="btn">

</form>
</html>
