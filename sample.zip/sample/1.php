<html>
<head><title>add</title>
</head>
<body>

<?php

$a=100;
$b=29;

$c=$a+$b;
echo "sum is".$c;


?>
</body>
</html>