
<?php
$conn=@mysql_connect("localhost","root","") or die('unable to connect');
//echo "connected"; 
@mysql_select_db("dbvcare",$conn) or die('could not find db');
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<title>Beauty</title>
	<!-- Meta Tags -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="utf-8">
	<meta name="keywords" content="Gleam Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
	<script>
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!-- //Meta Tags -->
	<!-- Style-sheets -->
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" property="" />
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
	<link rel="stylesheet" href="css/lightbox.css">
	<link href="css/fontawesome-all.css" rel="stylesheet">
	<!--// Style-sheets -->
	<!--web-fonts-->
	<link href="//fonts.googleapis.com/css?family=Poiret+One" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
	<!--//web-fonts-->
	<style>
	input[type=text], input[type=password],input[type=email] {
    width:80%;
height:50px;
border-radius:15px 0 15px 0;
border:2px solid #fff;
margin-bottom:15px;
background: transparent;
color:#fff;
}

/* Set a style for all buttons */
button {
display:inline-block;
height:40px;
width:130px;
line-height:40px;
overflow:hidden;
position:relative;
text-align:center;
background:	#9932CC;
border-radius:25px;
color:#fff;

margin-top:20px;
<!--margin-top:20px;-->
}
button-text{
display:block;
height:100%;
position:relative;
top:0;
width:90%;
}
button:hover {
    opacity: 0.8;
}

/* Extra styles for the cancel button */
.cancelbtn {
    width: auto;
    padding: 10px 18px;
    background-color: #f44336;
}

/* Center the image and position the close button */
.imgcontainer,.imgcontainer1 {
    width:50px;
height:50px;
border-radius:50%;
background:white;
position:absolute;
top:-5%;
left:45%;
  
}

img.avatar {
    width:100%;
padding:5px; 
}

.container,.container1 {
    padding: 16px;
}

span.psw {
    float: center;
    padding-top: 16px;
	color:#fff;
	text-decoration:bold;
}

/* The Modal (background) */
.modal,.modal1 {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    left: 0;
    top: 0;
    width:100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
    padding-top: 60px;
}

/* Modal Content/Box */
<!--.modal-content {
    background-color: #fefefe;
    margin: 5px auto; /* 15% from the top and centered */
    border: 1px solid #888;
    width: 80%; /* Could be more or less, depending on screen size */
}-->
.modal-content,.modal-content1{
background:rgba(0,0,0,0.4);
	text-align:center;
	
	border:3px solid #fff;
	-webkit-border-radius:60px 0 60px 0;
	-moz-border-radius:60px 0 60px 0;
	border-radius:70px 0 70px 0;

}
.modal-content1,.modal-content label{

text-align:left;
color:#fff;
text-transform:uppercase;
font-weight:bold;
}

/* The Close Button (x) */
.close {
    position: absolute;
    left: 560px;
    top: 0;
    color: #000;
    font-size: 35px;
    font-weight: bold;
}
.close{
color:white;
}
.close:hover,
.close:focus {
    color: red;
    cursor: pointer;
}

/* Add Zoom Animation */
.animate {
    -webkit-animation: animatezoom 0.6s;
    animation: animatezoom 0.6s
}

@-webkit-keyframes animatezoom {
    from {-webkit-transform: scale(0)} 
    to {-webkit-transform: scale(1)}
}
    
@keyframes animatezoom {
    from {transform: scale(0)} 
    to {transform: scale(1)}
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
    span.psw {
       display: block;
       float: none;
	   text-align:center-left;
	  text-color:#fff;
    }
   <!--.cancelbtn {
       width: 100%;
    }
	.submit-btn{
	background:green;
	}-->
	
}
</style>
</head>

<body>
	 <!--banner -->
	<div class="top-bar_sub container-fluid p-3">
		<div class="row">
			<div class="col-sm-8 top-mid">
				<p class="paragraph-agileinfo">
					<i class="fas fa-map-marker-alt"></i> Thazhe chovva , kannur , Kerala </p>
				<p class="paragraph-agileinfo">
					<i class="fas fa-phone"></i> +91-8281177379</p>
			</div>
			<div class="col-sm-4 log-icons text-right">
 <?php 
if(isset($_GET['Success']))
{
	$error=$_GET['Success'];
	echo "<font color=green >".$error."</font>";
	
}
?>
<?php 
if(isset($_GET['error']))
{
	$error=$_GET['error'];
	echo "<font color=red >".$error."</font>";
	
}
?>
<?php 
if(isset($_SESSION['u_type']))
	{
					 
echo "<h4><font color=#330066>Hello &nbsp;".$_SESSION['u_name'];"</h4></font>";
	}
?>
				<!--<ul class="social_list1">

					<li class="text-center">
						<a href="https://www.faceboook.com" class="facebook1">
							<i class="fab fa-facebook-f"></i>

						</a>
					<!--</li>
					<li class="text-center mx-sm-3 mx-2">
						<a href="#" class="twitter2">
							<i class="fab fa-twitter"></i>

						</a>
					</li>
					<li class="text-center">
						<a href="#" class="dribble3">
							<i class="fab fa-dribbble"></i>
						</a>
					</li>
				</ul>-->
			</div>
		</div>
	</div>
	<div class="banner" id="home">
		<!-- header -->
		<header>
			<nav class="navbar navbar-expand-lg navbar-light bg-light top-header">
				<h1 class="logo">
					<a class="navbar-brand" href="navuser.php">
						<i class="fab fa-viadeo"></i>Beauty</a>
				</h1>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
				    aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>

				<div class="collapse navbar-collapse" id="navbarSupportedContent">
					<ul class="navbar-nav ml-auto">
						<li class="nav-item active">
							<a class="nav-link ml-lg-0" href="navuser.php">Home
								<span class="sr-only">(current)</span>
							</a>
						</li>
					<!--	<li class="nav-item">
							<a class="nav-link scroll" href="#about">About</a>
						</li>
						<li class="nav-item">
							<a class="nav-link scroll" href="#gallery">Gallery</a>
						</li>-->
						<li class="nav-item">
							<button  class="nav-link scroll" style="background:transparent" onclick="location.href='../ltr/product.php';" style="width:auto;">Packages</button>
						</li>
						<?php
				
				
				 if(isset($_SESSION['u_type']))
				 {
					 ?>
						<li class="nav-item">
							<button  class="nav-link scroll" style="background:transparent" onclick="location.href='../ltr/logout.php';" style="width:auto;">Logout</button>
						</li>
						<?php
				
				 }
				 else{ 
					 ?>
						<li class="nav-item">
							<button  class="nav-link scroll" style="background:transparent" onclick="document.getElementById('id01').style.display='block'" style="width:auto;">Login</button>
						</li>
						<div id="id01" class="modal">
  
  <form class="modal-content animate" action="../ltr/loginaction.php" method="POST">
    <div class="imgcontainer">
      <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close">&times;</span>
      	<img src="../ltr/images/log1.jpg" alt="Avatar" class="avatar">
    </div>

    <div class="container">
	<br><br><br><br>
      <label for="uname" ><b>Email:</b></label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      <input type="email" placeholder="abc@example.com" pattern="[a-z0-9._%+-]+@(?=gmail.com|hotmail.com)[a-z0-9.-]+\.[a-z]{2,}$"  name="uname" required>
									    
<br>
      <label for="psw"><b>Password:</b></label>
      <input type="password" placeholder=""  pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 6 or more characters"  name="upassword" required>
        <br>
      <button  type="submit">Login</button> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      <button type="button" onclick="document.getElementById('id01').style.display='none'" style="background-color:red">Cancel</button>
	  <br>
	  <a class="nav-link " href="../ltr/forgot_password.php">Forgot Password?</a>
	  <br>
	 
	  </div>
	  
    <!--  <label>
        <input type="checkbox" checked="checked" name="remember"> Remember me
      </label>
   
	   l</button>
 

      <span class="psw">Forgot <a href="#">password?</a></span>
	  <p class="text-center text-muted">Not registered yet?</p>
                        <p class="text-center text-muted"><a href="register.html"><strong>Register now</strong></a>! It is easy and done in 1&nbsp;minute and gives you access to special discounts and much more!</p>
-->
    </div>
  </form>
 
  						<li class="nav-item">
							<button  class="nav-link scroll" style="background:transparent" onclick="document.getElementById('id02').style.display='block'" style="width:auto;">Register</button>
						</li>
						 </div>
							<?php
				 }
				 ?>
				
 <div id="id02" class="modal">
  
  <form class="modal-content animate" action="../ltr/register_action.php" method="POST" oninput="result.value=!!c_password.value&&(c_password.value==confirm_password.value)?'Match!':' Password Mismatch'">
    <div class="imgcontainer">
      <span onclick="document.getElementById('id02').style.display='none'" class="close" title="Close">&times;</span>
      	<img src="../ltr/images/log1.jpg" alt="Avatar" class="avatar">
    </div>

    <div class="container">
	<br><table align="center">
	<col width="300">
	<col width="300">
     <tr><td><label for="uname" ><b>First Name:</b></label></td>
	 <td>
    <input type="text" placeholder="" name="c_Fname"  pattern="[A-Za-z]{1,10}"  title="please insert only letters" required></td></tr> 
	   <tr><td><label for="uname" ><b>Last Name:</b></label></td>
     <td><input type="text" placeholder="" name="c_Lname"   pattern="[A-Za-z]{1,10}"  title="please insert only letters" required></td></tr>
<tr><td>
<label for="umail" ><b>Email:</b></label></td>
   <td>   <input type="email" placeholder="" name="c_email" pattern="[a-z0-9._%+-]+@(?=gmail.com|hotmail.com)[a-z0-9.-]+\.[a-z]{2,}$" required></td></tr>
<tr><td>
     <label for="psw"><b>Password:</b></label></td>
      <td><input type="password" placeholder="" name="c_password"  pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 6 or more characters" onchange=" if(this.checkValidity()) form.confirm_password.pattern = this.value;" required>
     </td></tr>
    <tr><td>  <label for="psw"><b>Confirm Password:</b></label> </td>
	  <td>
      <input type="password" placeholder="" name="confirm_password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 6 or more characters" onchange="this.setCustomValidity(this.validity.patternMismatch ? 'Password Mismatch' : '');"    required>
     </td></tr>
	 <tr><td> <label for="question"><b>Select an option:</b></label> </td>
	  <td>
	  <select name="security_q" class="" required>
											<option name="opt1" value="what's your favourite color?">what's your favourite color?</option>
											<option name="opt2" value="your pincode">your place</option>
											<option name="opt3" value="your pet name">your pet name</option>
											<option name="opt4" value="Your college name">Your college name</option>
											</select></td></tr>
				<tr><td><label for="question"><b>Your Answer:</b></label> </td>		
<td>	<input type="text" placeholder="" name="sec_answer"  required></td></tr>			
	 <tr><td>
     <button   type="submit">REGISTER</button></td>
   <td> <button type="button" onclick="document.getElementById('id02').style.display='none'" style="background-color:red">CANCEL</button></td></tr>
   </table>
	</div> 
	</form>
	
 </div>
	



<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>
						</li>
					</ul>
				</div>
			</nav>
		</header>
		<!-- //header -->
		<!-- banner-text
		<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
			<div class="carousel-inner text-right">
				<div class="carousel-item b1 active">
					<div class="container banner-w3layouts-info">
						<h3>Revitalizing beauty</h3>
						<p class="mt-lg-4 mt-md-3 mt-2 py-2 px-3">Revitalizing beauty for your skin</p>
					</div>
				</div>
				<div class="carousel-item b2">
					<div class="container banner-w3layouts-info">
						<h3>Relax & Refresh</h3>
						<p class="mt-lg-4 mt-md-3 mt-2 py-2 px-3">Beauty tips for a fresh start</p>
					</div>
				</div>
				<div class="carousel-item b3">
					<div class="container banner-w3layouts-info">
						<h3>Real Beauty</h3>
						<p class="mt-lg-4 mt-md-3 mt-2 py-2 px-3">Naturally Effective Health Solutions</p>
					</div>
				</div>
			</div>
			<a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
				<span class="carousel-control-prev-icon" aria-hidden="true"></span>
				<span class="sr-only">Previous</span>
			</a>
			<a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
				<span class="carousel-control-next-icon" aria-hidden="true"></span>
				<span class="sr-only">Next</span>
			</a>
		</div>
	</div>
	<!-- //banner -->
	<!--about
	<section class="banner-w3-agileits-btm-right py-5" id="about">
		<div class="container py-xl-5 py-sm-3">
			<h5 class="main-w3l-title mb-sm-4 mb-3">About Us</h5>
			<div class="row">
				<div class="col-lg-6 about-left">
					<h3 class="subheading-wthree mb-md-4 mb-3">Naturally Effective Health Solutions</h3>
					<p class="paragraph-agileinfo">There are loads of anti-aging supplements out there that promise to make you look younger.
					We dove into research and talked to top dermatologists to find the few worth popping. </p>


					<!-- Clients 
					<div class="slider mt-md-4 mt3 mb-3">
						<h3 class="subheading-wthree mb-md-4 mb-3">Some of Our Clients Saying About Us</h3>
						<div class="flexslider">
							<ul class="slides">
								<li>
									<div class="client-grids">
										<img src="images/c11.jpg" class="img-fluid" alt="Responsive image">
										<h4 class="mt-3 mb-1">Annie Robin</h4>
										<p class="paragraph-agileinfo"> The results are superb, loved it .Best services ever</p>
									</div>
								</li>
								<li>
									<div class="client-grids">
										<img src="images/c12.jpg" class="img-fluid" alt="Responsive image">
										<h4 class="mt-3 mb-1">Lausy Michael</h4>
										<p class="paragraph-agileinfo">The team is really friendly and good at every services.</p>
									</div>
								</li>
								<li>
									<div class="client-grids">
										<img src="images/c13.jpg" class="img-fluid" alt="Responsive image">
										<h4 class="mt-3 mb-1">Riya Doe</h4>
										<p class="paragraph-agileinfo"> They are trustable and give clear suggestions.</p>
									</div>
								</li>
							</ul>
						</div>
					</div>
				</div>
				<!--// Clients
				<div class="col-lg-6 mt-lg-0 mt-5">
					<div class="ab1 mr-auto"></div>
					<div class="ab2 my-4 ml-auto"></div>
					<div class="ab3 mr-auto"></div>
				</div>
			</div>
		</div>
	</section>
	<!--//about-->
	<!--services-->
	<section class="services-section py-5" id="services">
		<div class="container pt-xl-5 pt-sm-3">
			<h5 class="main-w3l-title mb-sm-4 mb-3">Services & Prices</h5>
			<div class="srategy-text mb-5">
				<p class="paragraph-agileinfo">Spa Services & Pricing subject to change.
				All the services are done by and under the supervision of qualified and certified professionals. 
				</p>
			</div>
		</div>
		<div class="container-fluid pb-xl-5 pb-sm-3">
			<div class="services-main row d-lg-flex justify-content-around">
			<?php
                    
$select="select * from tbl_packages ";
$view=mysql_query($select,$conn);
$count=mysql_num_rows($view);
if($count!=0)
{
	while($row2=mysql_fetch_array($view))
{
	//$id=$row2['l_id'];
	$p_name=$row2['pack_name'];
	$p_description=$row2['description'];
	$p_price=$row2['pack_price'];
	//$p_time=$row2['pack_time'];
	//$p_image=$row2['pack_image'];


	?>
		
				<div class="col-xl-3 col-md-6 col-12 service-grids-agileits-w3layouts">
				
				<div class="services-w3-agile-info p-4">
					
						<div class="bb1 mb-3">
							<img src="images/bb1.jpg" class="img-fluid mb-3" alt="Responsive image">
						</div>
						<h3 class="subheading-wthree mb-md-4 mb-3"><?php echo $p_name;?></h3>
						<p class="paragraph-agileinfo text-white">
						<?php echo $p_description;?> 
						</p>
						<h6 class="mt-2">
							<span class="mr-2">&#8377;<?php echo $p_price;?></span>
					
					</div>
					
				
				</div>
				<?php 
	}
	}
	?>
				
				
				<!--<div class="col-xl-3 col-md-6 col-12 service-grids-agileits-w3layouts mt-md-0 mt-4">
					<div class="services-w3-agile-info p-4">
						<div class="bb2 mb-3">
							<img src="images/bb2.jpg" class="img-fluid mb-3" alt="Responsive image">
						</div>
						<h3 class="subheading-wthree mb-md-4 mb-3">Hair Styling</h3>
						<p class="paragraph-agileinfo text-white">We offer a wide array of services such as styling, cutting, trimming, and coloring hair. 
						Price varies depending on the package you choose.</p>
						<h6 class="mt-2">
							<span class="mr-2">&#8377;</span>100</h6>
					</div>
				</div>-->
				
				
				<!--<div class="col-xl-3 col-md-6 col-12 service-grids-agileits-w3layouts mt-xl-0 mt-4">
					<div class="services-w3-agile-info p-4">
						<div class="bb3 mb-3">
							<img src="images/bb3.jpg" class="img-fluid mb-3" alt="Responsive image">
						</div>
						<h3 class="subheading-wthree mb-md-4 mb-3">Facial Care</h3>
						<p class="paragraph-agileinfo text-white">Shop skin care sets VCare. 
						These value sets and mini-sets are great for travel and fit perfectly in your purse or bag for on-the-go skin perfection.</p>
						<h6 class="mt-2">
							<span class="mr-2">&#8377;</span>500</h6>
					</div>
				</div>
				<div class="col-xl-3 col-md-6 col-12 service-grids-agileits-w3layouts mt-xl-0 mt-4">
					<div class="services-w3-agile-info p-4">
						<div class="bb4 mb-3">
							<img src="images/bb4.jpg" class="img-fluid mb-3" alt="Responsive image">
						</div>
						<h3 class="subheading-wthree mb-md-4 mb-3">Make Up</h3>
						<p class="paragraph-agileinfo text-white">Safe ingredients are used on sensitive skin,acne-prone skin,injured skin, perioral dermatitis,and rosacea. 
						</p>
						<h6 class="mt-2">
							<span class="mr-2">&#8377;</span>5000</h6>
					</div>
				</div>-->
				
				
			</div>
				
		</div>
		
	</section>
	<!--//services-->

	<!-- Team 
	<section class="team-section py-5" id="team">
		<div class="container py-xl-5 py-sm-3">
			<h5 class="main-w3l-title mb-sm-4 mb-3">About Our Team</h5>
			<div class="row">
				<div class="col-lg-6 team-left">
					<div class="row">
						<p class="paragraph-agileinfo">Team momentum and excitement are infectious. 
						Teamwork pulls people together in the most positive and inspiring way.</p>
						<div class="col-sm-6 col-11 mx-auto grid_info_w3ls mt-4">
							<img src="images/c35.jpg" class="img-fluid" alt="Responsive image">
							<div class="team_info p-3">
								<h5 class="text-white">Pearly Chris</h5>
								<span class="mt-1 mb-2">Makeup Specialist</span>
								<!--<ul class="social_list1">
									<li>
										<a href="#" class="facebook1 text-center">
											<i class="fab fa-facebook-f"></i>

										</a>
									</li>
									<li>
										<a href="#" class="twitter2 text-center">
											<i class="fab fa-twitter"></i>

										</a>
									</li>
									<li>
										<a href="#" class="dribble3 text-center">
											<i class="fab fa-dribbble"></i>
										</a>
									</li>
								</ul>
							</div>
						</div>
						<div class="col-sm-6 col-11 mx-auto grid_info_w3ls mt-4">
							<div class="team_info p-3">
								<h5 class="text-white">Andrue Hume</h5>
								<span class="mt-1 mb-2">Hair Stylist</span>
								<!--<ul class="social_list1">
									<li>
										<a href="#" class="facebook1 text-center">
											<i class="fab fa-facebook-f"></i>

										</a>
									</li>
									<li>
										<a href="#" class="twitter2 text-center">
											<i class="fab fa-twitter"></i>

										</a>
									</li>
									<li>
										<a href="#" class="dribble3 text-center">
											<i class="fab fa-dribbble"></i>
										</a>
									</li>
								</ul>
							</div>
							<img src="images/c4.jpg" class="img-fluid" alt="Responsive image">
						</div>
					</div>
				</div>
				<div class="col-lg-6 team-right">
					<div class="row">
						<p class="paragraph-agileinfo order-lg-2 mt-lg-3 mt-4">
						 The salon/spa’s team spirit is strong enough,
						even the self-proclaimed diehard loners and change resisters will find themselves subtly seeking a way to align with our team.</p>
						<div class="col-sm-6 col-11 mx-auto grid_info_w3ls mt-lg-0 mt-4">
							<img src="images/ch2.jpg" class="img-fluid" alt="Responsive image">
							<div class="team_info p-3">
								<h5 class="text-white">Albin Mathew</h5>
								<span class="mt-1 mb-2">Product Analyst</span>
								<!--<ul class="social_list1">
									<li>
										<a href="#" class="facebook1 text-center">
											<i class="fab fa-facebook-f"></i>

										</a>
									</li>
									<li>
										<a href="#" class="twitter2 text-center">
											<i class="fab fa-twitter"></i>

										</a>
									</li>
									<li>
										<a href="#" class="dribble3 text-center">
											<i class="fab fa-dribbble"></i>
										</a>
									</li>
								</ul>
							</div>
						</div>
						<div class="col-sm-6 col-11 mx-auto grid_info_w3ls mt-lg-0 mt-4">
							<div class="team_info p-3">
								<h5 class="text-white">Rose Roshan</h5>
								<span class="mt-1 mb-2"> Pedicure and Massage Instructor</span>
								<!--<ul class="social_list1">
									<li>
										<a href="#" class="facebook1 text-center">
											<i class="fab fa-facebook-f"></i>

										</a>
									</li>
									<li>
										<a href="#" class="twitter2 text-center">
											<i class="fab fa-twitter"></i>

										</a>
									</li>
									<li>
										<a href="#" class="dribble3 text-center">
											<i class="fab fa-dribbble"></i>
										</a>
									</li>
								</ul>
							</div>
							<img src="images/c3.jpg" class="img-fluid" alt="Responsive image">
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
<!-- Team -->

	<!--subscribe
	<section class="subscribe-section py-5">
		<div class="container py-xl-5 py-sm-3">
			<div class="subscribe-bg p-sm-4 p-3">
				<h5 class="main-w3l-title mb-sm-4 mb-3 text-white">
					<span>30% OFF</span> for All Massages</h5>
				<p class="paragraph-agileinfo text-white mb-3">Subscribe to our newsletter to receive updates from us.</p>
				<form action="../ltr/subscribe_action.php" method="post" class="d-sm-flex">
					<div class="form-group">
						<input type="email" class="form-control" name="sub_email" placeholder="name@example.com" required="">
					</div>
					<button type="submit" class="btn btn-primary">Subscribe</button>
				</form>
			</div>
		</div>
	</section>
	<!--//subscribe-->
	<!-- pricing 
	<section class="pricing-section py-5" id="pricing">
		<div class="container py-xl-5 py-sm-3">
			<h5 class="main-w3l-title mb-sm-4 mb-3">Our Price Table</h5>
			<div class="card-deck text-center">
				<div class="card box-shadow col-lg-4">
					<div class="card-header">
						<h4 class="py-md-4 py-3">Basic</h4>
					</div>
					<div class="card-body">
						<h5 class="card-title pricing-w3-agileits-title">
							<span class="align-top">&#8377;</span>250
							<small class="text-muted">/ month</small>
						</h5>
						<ul class="list-unstyled mt-3 mb-4">
							<li class="py-2 border-bottom">Relaxing Massage</li>
							<li class="py-2 border-bottom">Body Polish</li>
							<li class="py-2 border-bottom">Signature Facial</li>
						</ul>
						<a href="#contact" class="btn btn-block btn-outline-primary scroll py-2">Contact</a>
					</div>
				</div>
				<div class="card box-shadow col-lg-4 my-lg-0 my-3">
					<div class="card-header">
						<h4 class="py-md-4 py-3">Professional</h4>
					</div>
					<div class="card-body">
						<h5 class="card-title pricing-w3-agileits-title">
							<span class="align-top">&#8377;</span>300
							<small class="text-muted">/ month</small>
						</h5>
						<ul class="list-unstyled mt-3 mb-4">
							<li class="py-2 border-bottom">Body Polish</li>
							<li class="py-2 border-bottom">Signature Facial</li>
							<li class="py-2 border-bottom">Sensorial 50-minute Massage</li>
						</ul>
						<a href="#contact" class="btn btn-block btn-outline-primary scroll py-2">Contact</a>
					</div>
				</div>
				<div class="card box-shadow col-lg-4">
					<div class="card-header">
						<h4 class="py-md-4 py-3">Exclusive</h4>
					</div>
					<div class="card-body">
						<h5 class="card-title pricing-w3-agileits-title">
							<span class="align-top">&#8377;</span>450
							<small class="text-muted">/ month</small>
						</h5>
						<ul class="list-unstyled mt-3 mb-4">
							<li class="py-2 border-bottom">Imperiale Relaxing Massage</li>
							<li class="py-2 border-bottom">Intensive Facial Luxury</li>
							<li class="py-2 border-bottom">Manicure & Pedicure</li>
						</ul>
						<a href="#contact" class="btn btn-block btn-outline-primary scroll py-2">Contact</a>
					</div>
				</div>
			</div>

		</div>
	</section>
	<!-- //pricing -->
	<!-- gallery 
	<section class="gallery" id="gallery">
		<div class="container">
			<h5 class="main-w3l-title mb-sm-4 mb-3">Gallery</h5>
		</div>
		<div class="container-fluid">
			<div class="agileinfo-gallery row">
				<div class="col-lg-3 col-6 w3-agileits-gallery-grids mb-lg-0 mb-4">
					<a href="images/g1.jpg" data-lightbox="example-set" data-title="wrist mehndi for bride.">
						<img src="images/g1.jpg" class="img-fluid" alt="Responsive image">
						<div class="agile-b-wrapper">
							<h5>VCare</h5>
						</div>
					</a>
				</div>
				<div class="col-lg-3 col-6 w3-agileits-gallery-grids mb-lg-0 mb-4">
					<a href="images/g2.jpg" data-lightbox="example-set" data-title="Swedish massage.Best for: Relaxation, stress relief.
Deep tissue massage..">
						<img src="images/g2.jpg" class="img-fluid" alt="Responsive image">
						<div class="agile-b-wrapper">
							<h5>VCare</h5>
						</div>
					</a>
				</div>
				<div class="col-lg-6 w3-agileits-gallery-grids gallery-two">
					<a href="images/g3.jpg" data-lightbox="example-set" data-title="Bridal Makeup Looks, Indian Bridal Makeup, Indian Bridal Wear, 
					Wedding Makeup, Kerala Bride, Hindu Bride, South Indian Bride, Saree Wedding..">"
						<img src="images/g3.jpg" class="img-fluid" alt="Responsive image">
						<div class="agile-b-wrapper">
							<h5>Beauty</h5>
						</div>
					</a>
				</div>
				<div class="col-lg-6 w3-agileits-gallery-grids agileits-gallery-grids gallery-two mt-4">
					<a href="images/g4.jpg" data-lightbox="example-set" data-title="A pedicure is a cosmetic treatment of the feet and toenails, analogous to a manicure. 
					Pedicures are done for cosmetic, therapeutic purposes.">"
						<img src="images/g4.jpg" class="img-fluid" alt="Responsive image">
						<div class="agile-b-wrapper">
							<h5>Beauty</h5>
						</div>
					</a>
				</div>
				<div class="col-lg-3 col-6 w3-agileits-gallery-grids agileits-gallery-grids mt-4">
					<a href="images/g5.jpg" data-lightbox="example-set" data-title="Looking for a perfect Bridal Makeup? At VCare check out our best bridal makeup tips,
					ideas that will make you look flawless in all your wedding pictures.">
						<img src="images/g5.jpg" class="img-fluid" alt="Responsive image">
						<div class="agile-b-wrapper">
							<h5>Beauty</h5>
						</div>
					</a>
				</div>
				<div class="col-lg-3 col-6 w3-agileits-gallery-grids agileits-gallery-grids mt-4">
					<a href="images/g6.jpg" data-lightbox="example-set" data-title=" Your nails aren't going to change the world, but the woman who wears them will.">
						<img src="images/g6.jpg" class="img-fluid" alt="Responsive image">
						<div class="agile-b-wrapper">
							<h5>Beauty</h5>
						</div>
					</a>
				</div>
			</div>
		</div>
	</section>
	<!--// gallery -->
	<!-- contact 
	<section class="contact-section py-5" id="contact">
		<div class="container py-xl-5 py-sm-3">
			<h5 class="main-w3l-title mb-sm-4 mb-3">Contact Us</h5>
			<div class="row">
				<div class="col-lg-8 wthree_contact_left">
					<h3 class="subheading-wthree mb-md-4 mb-3">Send us an Email</h3>
					<form action="../ltr/contact_action.php" method="POST">
						<div class="form-row">
							<div class="form-group col-md-6">
								<input type="text" class="form-control" placeholder="Name" name="cust_name" required="">
							</div>
							<div class="form-group col-md-6">
								<input type="text" class="form-control" placeholder="phone" name="cust_phone" required="">
							</div>
							<div class="form-group col-md-6">
								<input type="email" class="form-control" placeholder="Email" name="cust_email"required="">
							</div>
							<div class="form-group col-md-6">
								<input type="text" class="form-control" placeholder="Subject" name="subject" required="">
							</div>
						</div>
						<div class="form-group">
							<textarea id="textarea" placeholder="Message..." name="message" required=""></textarea>
						</div>
						<button type="submit" class="btn btn-primary py-sm-3 py-2 px-5">Submit</button>
					</form>
				</div>
				<div class="col-lg-4 wthree_contact_right mt-lg-0 mt-sm-5 mt-4">
					<h3 class="subheading-wthree mb-md-4 mb-3">Get In Touch</h3>
					<address>
						<p class="paragraph-agileinfo mb-md-4 mb-3">
							<i class="fas fa-map-marker-alt mr-3"></i>Beauty salon,thazhe chovva, kannur, kerala, India</p>

						<p class="paragraph-agileinfo mb-md-4 mb-3">
							<i class="fas fa-phone mr-3"></i> +91-8281177576</p>

						<p class="paragraph-agileinfo mb-md-4 mb-3">
							<i class="fas fa-fax mr-3"></i> 0460-229154</p>

						<p class="paragraph-agileinfo">
							<i class="far fa-envelope mr-3"></i>
							<a href="mailto:info@example.com">beauty@gmail.com</a>
						</p>
					</address>
				</div>
			</div>
		</div>
	</section>

	<!-- contact

	<div class="map-section">
		<iframe src="https://maps.google.com/maps?q=india%20kannur%20thazhe%20chovva%20fair%20touch%20beauty%20parlour%20and%20saloon&t=&z=13&ie=UTF8&iwloc=&output=embed"></iframe>
	</div>-->
	<footer class="footer-section">
		<div class="container">
			<div class="footer-right py-5">
				<div class="row">
					<div class="col-lg-6 col-md-6 footer-grids">
						<h2>About Us</h2>
						<p class="paragraph-agileinfo">Team momentum and excitement are infectious. 
						Teamwork pulls people together in the most positive and inspiring way.</p>
					</div>
					<div class="col-lg-3 footer-grids mt-lg-0 mt-4">
						<h3>Usefull Links</h3>
						<ul class="w3agile_footer_grid_list">
							<li>
								<a href="navuser.php">Home</a>
							</li>
							<li>
								<a href="#about" class="scroll">About</a>
							</li>
							<li>
								<a href="#gallery" class="scroll">Gallery</a>
							</li>
							<li>
								<a href="#services" class="scroll">Services</a>
							</li>
							<li>
								<a href="#contact" class="scroll">Contact</a>
							</li>
						</ul>
					</div>
					<!--<div class="col-lg-3 footer-grids mt-lg-0 mt-4">
						<h3>Social Media</h3>
						<ul class="social_list1">
							<li class="text-center">
								<a href="#" class="facebook1">
									<i class="fab fa-facebook-f"></i>

								</a>
							</li>
							<li class="text-center mx-sm-3 mx-2">
								<a href="#" class="twitter2">
									<i class="fab fa-twitter"></i>

								</a>
							</li>
							<li class="text-center">
								<a href="#" class="dribble3">
									<i class="fab fa-dribbble"></i>
								</a>
							</li>
						</ul>
					</div>-->
				</div>
			</div>
		</div>
	</footer>
	
	<!-- Required common Js -->
	<script src='js/jquery-2.2.3.min.js'></script>
	<!-- //Required common Js -->
	<!-- flexSlider -->
	<script defer src="js/jquery.flexslider.js"></script>
	<script>
		$(window).load(function () {
			$('.flexslider').flexslider({
				animation: "slide",
				start: function (slider) {
					$('body').removeClass('loading');
				}
			});
		});
	</script>

	<!-- //flexSlider -->

	<!--light-box-files -->
	<script src="js/lightbox-plus-jquery.min.js">
	</script>
	<!--//light-box-files -->


	<!-- start-smoth-scrolling -->
	<script src="js/move-top.js"></script>
	<script src="js/easing.js"></script>
	<script>
		jQuery(document).ready(function ($) {
			$(".scroll").click(function (event) {
				event.preventDefault();
				$('html,body').animate({
					scrollTop: $(this.hash).offset().top
				}, 1000);
			});
		});
	</script>
	<!-- start-smoth-scrolling -->
	<!-- here stars scrolling icon -->
	<script>
		$(document).ready(function () {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear'
				};
			*/

			$().UItoTop({
				easingType: 'easeOutQuart'
			});

		});
	</script>
	<!-- //here ends scrolling icon -->
	<!-- Js for bootstrap working-->
	<script src="js/bootstrap.min.js"></script>
	<!-- //Js for bootstrap working -->
</body>

</html>