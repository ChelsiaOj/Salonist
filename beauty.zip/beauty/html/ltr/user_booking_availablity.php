
<?php
include("../ltr/dbconnect.php");
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<title>Beauty</title>
<link href="css1/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<!--theme-style-->
<link href="css1/style.css" rel="stylesheet" type="text/css" media="all" />	
  <link href="css/datetimepicker.css" rel="stylesheet" type="text/css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   <!-- <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ" crossorigin="anonymous"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.22.0/moment-with-locales.min.js"></script>
    <script type="text/javascript" src="js/datetimepicker.js"></script>
    <link href="https://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Shopin Responsive web template, Bootstrap Web Templates, Flat Web Templates, AndroId Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--theme-style-->
<link href="css1/style4.css" rel="stylesheet" type="text/css" media="all" />	
<!--//theme-style-->
<script src="js1/jquery.min.js"></script>


    

<!--- start-rate---->
<script src="js1/jstarbox.js"></script>
	<link rel="stylesheet" href="css1/jstarbox.css" type="text/css" media="screen" charset="utf-8" />
		<script type="text/javascript">
			jQuery(function() {
			jQuery('.starbox').each(function() {
				var starbox = jQuery(this);
					starbox.starbox({
					average: starbox.attr('data-start-value'),
					changeable: starbox.hasClass('unchangeable') ? false : starbox.hasClass('clickonce') ? 'once' : true,
					ghosting: starbox.hasClass('ghosting'),
					autoUpdateAverage: starbox.hasClass('autoupdate'),
					buttons: starbox.hasClass('smooth') ? false : starbox.attr('data-button-count') || 5,
					stars: starbox.attr('data-star-count') || 5
					}).bind('starbox-value-changed', function(event, value) {
					if(starbox.hasClass('random')) {
					var val = Math.random();
					starbox.next().text(' '+val);
					return val;
					} 
				})
			});
		});
		</script>
<!---//End-rate---->
<link href="css1/form.css" rel="stylesheet" type="text/css" media="all" />


<style>

#available{
	
	background-color:;
	text-color:black;
}

.checkbox-grid li {
    display: block;
    float: left;
    width: 30%;
}

</style>
</head>
<body>
<!--header-->
<div class="header">
<div class="container">
		<div class="head">
			<div class=" logo">
				
			</div>
		</div>
			
	</div>
	
		
		<div class="container">

			<div class="head-top">
		
		 <div class="col-sm-8 col-md-offset-2 h_menu4">	
				<nav class="navbar nav_bottom" role="navigation">
 
 <!-- Brand and toggle get grouped for better mobile display -->
  <div class="navbar-header nav_2">
      <button type="button" class="navbar-toggle collapsed navbar-toggle1" data-toggle="collapse" data-target="#bs-megadropdown-tabs">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"> </span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
     
   </div> 
   <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-megadropdown-tabs">	
<ul class="nav navbar-nav nav_1">
           <li><a class="color" href="navuser.php">Home</a></li>
            
    		
			
			<li><a class="color3" href="product.php">Services</a></li>
		
			 
			 <?php
 if(isset($_SESSION['u_type']))
				 {
					 ?>
			 
			 <li><a class="color5" href="user_booking_availablity.php"> Book Now</a></li>
			
          <li><a class="color5" href="user_history.php">My Account</a></li>
			<li><a class="color5" href="user_profile.php">Profile</a></li>
			<?php
				 }
			?>
			
        </ul>
     </div><!-- /.navbar-collapse -->

</nav>

			</div>
			
			<div class="col-sm-2 search-right">
			
				<ul class="heart">
				
				<li>
				<?php
				
				
				 if(isset($_SESSION['u_type']))
				 {
					 ?>
					  <?php
echo "<h4><font color=#330066>Hello &nbsp;".$_SESSION['u_name'];"</h4></font>"
?></li>
				<li ><a class="color6" href="../ltr/logout.php">Logout</a></li>
				<?php
				
				 }
				 else{ 
					 ?>
					 <li ><a class="color6" href="navuser.php">Login</a></li>
				<li ><a class="color6" href="navuser.php">Register</a></li>
				<?php
				 }
				 ?>
					</ul>
				 
					<div class="cart box_1">
						
						<h3> <div class="total">
							
						<!--<img src="images/cart.png" alt=""/></h3>
						
						<p><a href="javascript:;" class="simpleCart_empty">Empty Cart</a></p>-->

					</div>
					<div class="clearfix"> </div>
					
						<!----->

						<!---pop-up-box---->					  
			<link href="css1/popuo-box.css" rel="stylesheet" type="text/css" media="all"/>
			<script src="js1/jquery.magnific-popup.js" type="text/javascript"></script>
			<!---//pop-up-box---->
			<div id="small-dialog" class="mfp-hide">
				<div class="search-top">
					<div class="login-search">
						<input type="submit" value="">
						<input type="text" value="Search.." onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search..';}">		
					</div>
					<p>Beauty</p>
				</div>				
			</div>
		 <script>
			$(document).ready(function() {
			$('.popup-with-zoom-anim').magnificPopup({
			type: 'inline',
			fixedContentPos: false,
			fixedBgPos: true,
			overflowY: 'auto',
			closeBtnInside: true,
			preloader: false,
			midClick: true,
			removalDelay: 300,
			mainClass: 'my-mfp-zoom-in'
			});
																						
			});
		</script>		
						<!----->
			</div>
			<div class="clearfix"></div>
		</div>	
	</div>	
</div>
<!--banner
<div class="banner-top">
	<div class="container">
		<h1>Beauty</h1>
		<em></em>
		<h2>Packages</h2>
	</div>
</div>-->

<?php 
if(isset($_GET['Success']))
{
	$error=$_GET['Success'];
	echo "<h3 align='center'><font color=green >".$error."</h3></font>";
	
}
?>



	<!--content-->
		
			<!--<div class="container">
			<div class="col-md-9">-->
				
				<div class="container">
							
					
			
			
			<!--categories-->
				
				<!--initiate accordion-->
						<script type="text/javascript">
							$(function() {
							    var menu_ul = $('.menu-drop > li > ul'),
							           menu_a  = $('.menu-drop > li > a');
							    menu_ul.hide();
							    menu_a.click(function(e) {
							        e.preventDefault();
							        if(!$(this).hasClass('active')) {
							            menu_a.removeClass('active');
							            menu_ul.filter(':visible').slideUp('normal');	 	 	  
							            $(this).addClass('active').next().stop(true,true).slideDown('normal');
							        } else {
							            $(this).removeClass('active');
							            $(this).next().stop(true,true).slideUp('normal');
							        }
							    });
							
							});
						</script>
						<br><br>
						<div class="col-lg-8 col-xlg-9 col-md-7">
					<div class=" mid-pop">
						
			<form action="user_booking_action.php"   method="POST" enctype="multipart/form-data"> 
			<table width="30%">
			<tr>	<td>Select Service(*)</td>
			<td><!---<select name="service_name" id="service_name" onchange="getPrice(this.value)">
			<option>Select</option>
				 <!-- <select name="service_name" id="service_name"  onchange="getPrice(this.value);" ><option>select a service</option>  -->
				<?php 
				$sql="select * from tbl_packages";
				$res = mysql_query($sql);
			while($list = mysql_fetch_array($res)){
				$p_id=$list['pack_id'];
				$packName = $list['pack_name'];
				$packprice = $list['pack_price'];
				
				?>
				
				
		<input type="checkbox" name="service[]"	class="product" value="<?php   echo $packprice;?><?php echo $packName?>" onclick="totalIt()" />
		<?php   echo $packName?>
				
				
				<script>



function totalIt() {
    var input = document.getElementsByClassName("product");
	//window.alert(input);
    var total = 0;
   for (var i = 0; i < input.length; i++) {
   if (input[i].checked) {
     total += parseFloat(input[i].value);
    }
 }
document.getElementById("s_price").value =  total.toFixed(2);
 //window.alert(total.toFixed(2));
}
</script>
				<?php
				
			}
				?>
			<!--	</select>-->
				</td></tr>
			<!--	<tr>	<td>Select additional Service</td>
			<td><select id="serv_next" onchange="TotalPrice(this.value); Compare(this.value);" >
			<option>Select</option>
				<?php 
				$sql="select pack_name from tbl_packages";
				$res = mysql_query($sql);
			while($list = mysql_fetch_array($res)){
  
				$packName = $list['pack_name'];
				
				?>
				
				
		<option	value="<?php   echo $packName?>" ><?php   echo $packName?></option>
				
				<?php
				
			}
				?>
			</select>
			<td><span id="sAvailable"></span></td>
				</td></tr>-->
				<tr>	<td>price</td>
				<td>   <input type="text"  id="s_price" name="s_price" readonly>    </td></tr>
				<tr><td>Date</td>
				<td><input type="date" id="mydate" name="mydate" onchange="CheckFreeDate(this.value)" min="<?php echo date('Y-m-d');?>" required></td>
				<td><span id="available"></span></td>
				</tr>
				
				
				<tr>		<td>Booking Hours(1 hour time slot)</td>
							<td><select name="bTime" id="bTime" onchange="CheckTime(this.value)" required><option>Select Time</option>
							 <?php 
				$sql="select time from tbl_booking";
				$res = mysql_query($sql);
			while($list = mysql_fetch_array($res)){
  
				$pack = $list['time'];
				
				?>
							 <option name="time" value="<?php echo $pack;?>"><?php echo $pack; ?>
							  </option>
			   <?php 
				}
				?>
							
			
						</select>  	
						</td>
						<td><span id="TAvailable"></span></td>
				</tr>
				
				<tr>	<td>Your Id</td>
				<td>   <input type="text"  name="user" value="<?php echo $_SESSION['u_id']; ?>" readonly>    </td></tr>
				
				<!--<tr><td><input type="text"  required name="pack_date" id="theDate"  readonly></td></tr>-->
		</table>
				
			<input type="submit" name="submit" value="Continue Payment" class="btn btn-primary btn-sm btn-flat" />
			</form>
						
		</div>				
						
<!--//menu-->
 </div>
				   		
		
			<div class="clearfix"></div>
			
				<!--products-->
		
			<!--//products-->
		
			
			
		
	<div class="container">
			<div class="brand">
				<div class="col-md-3 brand-grid">
					<img src="images/ic.png" class="img-responsive" alt="">
				</div>
				<div class="col-md-3 brand-grid">
					<img src="images/ic1.png" class="img-responsive" alt="">
				</div>
				<div class="col-md-3 brand-grid">
					<img src="images/ic2.png" class="img-responsive" alt="">
				</div>
				<div class="col-md-3 brand-grid">
					<img src="images/ic3.png" class="img-responsive" alt="">
				</div>
				<div class="clearfix"></div>
			</div>
			</div>
			<!--//brand-->
		</div>	
		
	<!--//content-->
		<!--//footer-->
		<div class="footer">
	<div class="footer-middle">
				<div class="container">
					<div class="col-md-3 footer-middle-in">
						<a href="navuser.php"><h6>Beauty</h6></a>
						<p>There are loads of anti-ageing supplements out there that promise to make you look younger.
					We dove into research and talked to top dermatologists to find the few worth popping.</p>
					</div>
					
					<div class="col-md-3 footer-middle-in">
						<h6>Information</h6>
						<ul class=" in">
							<li><a href="navuser.php">About</a></li>
							<li><a href="navuser.php">Contact Us</a></li>
							
							
						</ul>
					<!--	<ul class="in in1">
							<li><a href="user_account.php">Order History</a></li>
							<li><a href="pro_cart.php">Cart</a></li>
							<li><a href="navuser.php">Login</a></li>
						</ul>-->
						<div class="clearfix"></div>
					</div>
					
					<div class="col-md-3 footer-middle-in">
						<h6>Newsletter</h6>
						<span>Sign up for News Letter</span>
							<form action="../ltr/subscribe_action.php"  method="post">
								<input type="text" name="sub_email" value="Enter your E-mail" onfocus="this.value='';" onblur="if (this.value == '') {this.value ='Enter your E-mail';}">
								<input type="submit" value="Subscribe">	
							</form>
					</div>
					<div class="clearfix"> </div>
				</div>
			</div>
			<div class="footer-bottom">
				<div class="container">
					<ul class="footer-bottom-top">
						<li><img src="images/f1.png" class="img-responsive" alt=""></li>
						<li><img src="images/f2.png" class="img-responsive" alt=""></li>
						<li><img src="images/f3.png" class="img-responsive" alt=""></li>
					</ul>
					
					<div class="clearfix"> </div>
				</div>
			</div>
		</div>
		<!--//footer-->
<script src="js1/imagezoom.js"></script>

	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script defer src="js1/jquery.flexslider.js"></script>
<link rel="stylesheet" href="css1/flexslider.css" type="text/css" media="screen" />

<script>
// Can also be used with $(document).ready()
$(window).load(function() {
  $('.flexslider').flexslider({
    animation: "slide",
    controlNav: "thumbnails"
  });
});

var limit = 3;
$('input.single-checkbox').on('change', function(evt) {
   if($(this).siblings(':checked').length >= limit) {
       this.checked = false;
   }
});

var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
var dateTime = date+' '+time;
document.getElementById('theDate').value = dateTime;


</script>

<script>
	function CheckFreeDate(){
    var BDate = document.getElementById('mydate');
    if(BDate != "")
    {
        if (window.XMLHttpRequest)
        {// code for IE7+, Firefox, Chrome, Opera, Safari
          xmlhttp=new XMLHttpRequest();
        }
        else
        {// code for IE6, IE5
          xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange=function()
        {
          if (xmlhttp.readyState==4 && xmlhttp.status==200)
            {
                var value = xmlhttp.responseText;
                if(value >= 36)
                {
                    document.getElementById('available').innerHTML="Date not available.";
					
                   BDate.focus();
                }
				
				
                else
                {
                  document.getElementById('available').innerHTML="Date available.";
                }
            }
          }
        xmlhttp.open("GET","user_date_action.php?q="+BDate.value,true);
        xmlhttp.send();
    }
}


	
	 
	
	function CheckTime(){
    var BTime = document.getElementById('bTime');
	
    if(BTime != "")
    {
        if (window.XMLHttpRequest)
        {// code for IE7+, Firefox, Chrome, Opera, Safari
          xmlhttp=new XMLHttpRequest();
        }
        else
        {// code for IE6, IE5
          xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange=function()
        {
          if (xmlhttp.readyState==4 && xmlhttp.status==200)
            {
                var val = xmlhttp.responseText;
                if(val >=3)
                {
                    document.getElementById('TAvailable').innerHTML="Time not available.";
					
                   BTime.focus();
                }
				
				
                else
                {
                  document.getElementById('TAvailable').innerHTML="Time available.";
                }
            }
          }
        xmlhttp.open("GET","user_date_action.php?t="+BTime.value,true);
        xmlhttp.send();
    }
}
	
	
	</script>


	<script src="js1/simpleCart.min.js">



	</script>
<!-- slide -->
<script src="js1/bootstrap.min.js"></script>


</body>
</html>

