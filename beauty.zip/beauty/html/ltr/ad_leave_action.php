<?php
session_start();



$conn=@mysql_connect("localhost","root","") or die('unable to connect');
 
@mysql_select_db("dbvcare",$conn) or die('could not find db');
if(isset($_POST['btnapprove']))
{
$id=$_POST['id'];

//echo $id;			
$query="update `tbl_leave` set `status`='1' where `l_id`='$id'";
mysql_query("$query",$conn);
header("location:../ltr/admin_employee_leave.php");
}		
if(isset($_POST['btndecline']))
{
$id=$_POST['id'];

echo $id;			
$query="update `tbl_leave` set `status`='2' where `l_id`='$id'";
mysql_query("$query",$conn);
header("location:../ltr/admin_employee_leave.php");
}		


?>