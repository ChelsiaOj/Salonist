<?php
session_start();
$conn=@mysql_connect("localhost","root","") or die('unable to connect');

@mysql_select_db("dbvcare",$conn) or die('could not find db');




 if(isset($_POST['submit']))
{

$s_name=  implode(',', $_POST['service']);
$service= preg_replace('/[0-9]+/', '', $s_name);
$s_time=$_POST['bTime'];
$s_date=$_POST['mydate'];
$user_id=$_POST['user'];
$s_price=$_POST['s_price'];
//echo $s_name;
//echo $service;
//eccho $service;
//echo $s_time;
//echo $s_date;
//echo $user_id;
//echo $s_price;
$query="INSERT INTO `tbl_cust_packages`(`cust_id`,`package`,`date`,`time`,`price`,`price_status`,`booking_status`) 
							VALUES('$user_id','$service','$s_date','$s_time','$s_price','0','0')";
				
		mysql_query("$query",$conn);
$id = mysql_insert_id();		
							
		//echo "<script>
//alert(' booking fai');
//window.location.href='../ltr/payment.php';
//</script>";
header("location:../ltr/payment.php?amount=$s_price,s_id=$id");
				
}


?>