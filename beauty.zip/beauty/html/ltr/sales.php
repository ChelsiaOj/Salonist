
<?php 
SELECT @rownum := @rownum + 1 rownum, 
       t.* 
  FROM (SELECT @rownum:=0) r, 
       (select case when indicator = 1 then Product
else concat( indicator, ' Products') end as Product, sales from 
(Select *, count(sales) as indicator from (SELECT Product,SUM(No_sold)
 AS sales FROM SalesRows
JOIN Products ON Products.Pid = SalesRows.Pid
WHERE Sales_date = curdate()
GROUP BY SalesRows.Pid ) a group by sales Order by sales desc) a) t
?>