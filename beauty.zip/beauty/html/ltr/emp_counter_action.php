<?php
session_start();
$conn=@mysql_connect("localhost","root","") or die('unable to connect');

@mysql_select_db("dbvcare",$conn) or die('could not find db');
if(isset($_POST['btnsave']))
{
if(isset($_POST['test']))
{

$state=$_POST['c_status'];
$c_id=$_POST['id'];
$query="update `tbl_cust_packages` set `booking_status`='1' where id='$c_id'";
mysql_query("$query",$conn);
$query1="update `tbl_counter` set `staff_attended`='".$_SESSION['u_id']."' where id='$c_id'";
mysql_query("$query1",$conn);


	header("location:../ltr/emp_counter.php");
		
			
}
else
{
	header("location:../ltr/emp_counter.php?error=select checkbox!");
}

}
?>



 
