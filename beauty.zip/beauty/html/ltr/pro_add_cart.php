<?php
if(isset($_POST['btncart']))
{
$id=$_POST['prod_id'];
$cust_id=$_SESSION['u_id'];
$stmt="insert into tbl_cart (`cust_id`,`product_id`) values ('$cust_id','$id')";
mysql_query($stmt,$conn);

}
header("location:../ltr/product.php");	
?>