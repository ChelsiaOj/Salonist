<?php
$conn=@mysql_connect("localhost","root","") or die('unable to connect');
@mysql_select_db("dbvcare",$conn) or die('could not find db');
session_start();
if(isset($_POST["btngenerate"])){
// Checking For Blank Fields..
if($_POST["emp_mail"]==""||$_POST["desig_emp"]==""){
echo "Fill All Fields..";
}
else{
// Check if the "Sender's Email" input field is filled out
$email=$_SESSION['u_id'];
$remail=$_POST['emp_mail'];
// Sanitize E-mail Address
$email =filter_var($email, FILTER_SANITIZE_EMAIL);
// Validate E-mail Address
$email= filter_var($email, FILTER_VALIDATE_EMAIL);
if (!$email){
echo "Invalid Sender's Email";
}
else{
$subject = " login credential from Vcare";
$message = $_POST['msg'];
$headers = 'From:'. $email . "rn"; // Sender's Email
$headers .= 'Cc:'. $email . "rn"; // Carbon copy to Sender
// Message lines should not exceed 70 characters (PHP rule), so wrap it
$message = wordwrap($message, 70);
// Send Mail By PHP Mail Function
mail($remail, $subject, $message, $headers);
echo "Login credentials sent Via mail";
}
}
}
?>