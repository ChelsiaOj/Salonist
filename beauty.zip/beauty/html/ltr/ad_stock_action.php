<?php
session_start();
$conn=@mysql_connect("localhost","root","") or die('unable to connect');

@mysql_select_db("dbvcare",$conn) or die('could not find db');
if(isset($_POST['btnadd']))
{

$pro_name=$_POST['pro_name'];
$description=$_POST['pro_desc'];
$pro_price=$_POST['pro_price'];
$pro_stock=$_POST['pro_quantity'];
$rawdate = htmlentities($_POST['pro_date']);
$pro_dateExp = date('Y-m-d', strtotime($rawdate));
$pro_company=$_POST['pro_company'];
$photo=$_FILES['image']['name'];
if(move_uploaded_file($_FILES['image']['tmp_name'],"../uploads/".$photo))
			{
				$query="INSERT INTO `tbl_products`(`pro_name`,`description`,`pro_price`, `pro_quantity`, `expiry_date`,`company`,`pro_photo`) 
							VALUES('$pro_name','$description','$pro_price','$pro_stock','$pro_dateExp','$pro_company','$photo')";
				
			mysql_query("$query",$conn);				
		
			}
			header("location:../ltr/admin_stock_table.php?Message=Product Added");
}
if(isset($_POST['btnedit']))
{
 $id=$_POST['id'];

$description=$_POST['pro_desc'];
$pro_price=$_POST['pro_price'];
$pro_stock=$_POST['pro_quantity'];
$rawdate = htmlentities($_POST['pro_date']);
$pro_dateExp = date('Y-m-d', strtotime($rawdate));
//$pro_company=$_POST['pro_company'];
//$photo=$_FILES['image']['name'];
//if(move_uploaded_file($_FILES['image']['tmp_name'],"../uploads/".$photo))
			//{
				
		$query="UPDATE `tbl_products` set `description`='$description',`pro_price`='$pro_price', 
				`pro_quantity`='$pro_stock', `expiry_date`='$pro_dateExp' where pro_id='$id'";

				
			mysql_query("$query",$conn);
			header("location:../ltr/admin_stock_table.php?Message=Product Edited");
			//}//
}


 if(isset($_POST['btndelete']))
 {
	  $id=$_POST['id'];
    $stmt="DELETE FROM tbl_products WHERE pro_id='$id'";
			mysql_query("$stmt",$conn);
			
			header("location:../ltr/admin_stock_table.php?Message=deleted successfully!");
			}
  

	
?>
