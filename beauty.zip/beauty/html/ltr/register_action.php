<?php
$conn=@mysql_connect("localhost","root","") or die('unable to connect');
//echo "connected"; 
@mysql_select_db("dbvcare",$conn) or die('could not find db');

$Fname=$_POST['c_Fname'];
$Lname=$_POST['c_Lname'];

$email=$_POST['c_email'];
$password=$_POST['confirm_password'];
//$sec_quest=$_POST['security_q'];
//$answer=$_POST['sec_answer'];

$query2="select * from tbl_login where u_id='$email'";
$set2=mysql_query("$query2",$conn);
$rowcount2=mysql_num_rows($set2);
if($rowcount2==0)
{
$query="INSERT INTO `tbl_u_detail`(`u_id`, `u_type`, `u_status`,`Fname`,`Lname`) VALUES('$email',2,1,'$Fname','$Lname')";
$result=mysql_query("$query",$conn);

$ins="INSERT INTO `tbl_login`(`u_id`, `u_password`) VALUES ('$email','$password')";
$sett=mysql_query("$ins",$conn);

//$sql1="INSERT INTO `tbl_address`(`u_id`) VALUES('$email')";
//$set1=mysql_query("$sql1",$conn);
//$sql2="INSERT INTO `tbl_ship_address`(`u_id`) VALUES('$email')";
//$set2=mysql_query("$sql2",$conn);

	header("location:../ltr/navuser.php?Success=Welcome to Beauty.Login to account !");
}
else
{
	
	header("location:../ltr/navuser.php?error=Sorry..!User exists.Please use another account!");
}

?>
