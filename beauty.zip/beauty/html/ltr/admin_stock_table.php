<?php
include("../ltr/dbconnect.php");

session_start();
$u_id=$_SESSION['u_id'];
$u_pass=$_SESSION['u_pass'];
$u_type=$_SESSION['u_type'];
$sql="select * from tbl_login where u_id='$u_id'  and u_password='$u_pass' ";
$result=mysql_query($sql,$conn);
$rowcount=mysql_num_rows($result);
$sql1="select * from tbl_u_detail where u_id='$u_id' ";
$result1=mysql_query($sql1,$conn);
$row=mysql_fetch_array($result1);
if($rowcount==1 && $u_type=="admin")
{
?>


<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="../../assets/images/favicon.png">
    <title>Stock</title>
    <!-- Custom CSS -->
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" property="" />
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
	<link rel="stylesheet" href="css/lightbox.css">
	<link href="css/fontawesome-all.css" rel="stylesheet">
    <link href="../../dist/css/style.min.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<style>
.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    padding-top: 100px; /* Location of the box */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.modal-content {
    position: relative;
    background-color: #fefefe;
    margin: auto;
    padding: 0;
    border: 1px solid #888;
    width: 60%;
	height:60%;
    box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);
    -webkit-animation-name: animatetop;
    -webkit-animation-duration: 0.4s;
    animation-name: animatetop;
    animation-duration: 0.4s
}

/* Add Animation */
@-webkit-keyframes animatetop {
    from {top:-300px; opacity:0} 
    to {top:0; opacity:1}
}

@keyframes animatetop {
    from {top:-300px; opacity:0}
    to {top:0; opacity:1}
}

/* The Close Button */
.close {
   position: absolute;
    left: 750px;
    top: 0;
    color: red;
    font-size: 35px;
    font-weight: bold;
}

.close:hover,
.close:focus {
	color: red;
    cursor: pointer;
    
    text-decoration: none;
    
}

.modal-header {
    /*padding: 2px 16px;*/
    background-color: #5cb85c;
    color: white;
}

.modal-body {padding: 2px 16px;}


</style>
</style>
</head>

<body>

    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper" data-navbarbg="skin6" data-theme="light" data-layout="vertical" data-sidebartype="full" data-boxed-layout="full">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <header class="topbar" data-navbarbg="skin6">
            <nav class="navbar top-navbar navbar-expand-md navbar-light">
                <div class="navbar-header" data-logobg="skin5">
                    <!-- This is for the sidebar toggle which is visible on mobile only -->
                    <a class="nav-toggler waves-effect waves-light d-block d-md-none" href="javascript:void(0)">
                        <i class="ti-menu ti-close"></i>
                    </a>
                    <!-- ============================================================== -->
                    <!-- Logo -->
                    <!-- ============================================================== -->
					<div class="navbar-brand">
					<h1 class="logo">
					<a class="navbar-brand" href="index.php">
						<i class="fab fa-viadeo"></i>Beauty</a>
				</h1>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
				    aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
                 
                    </div>
                   
                    <a class="topbartoggler d-block d-md-none waves-effect waves-light" href="javascript:void(0)" data-toggle="collapse" data-target="#navbarSupportedContent"
                        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="ti-more"></i>
                    </a>
                </div>
              
                <div class="navbar-collapse collapse" id="navbarSupportedContent" data-navbarbg="skin6">
                    
                    <ul class="navbar-nav float-left mr-auto">
					<?php
echo "<h4><font color=#330066>Hello &nbsp;".$_SESSION['u_name'];"</h4></font>"
?>
                       
                       
                    </ul>
                  
                    <ul class="navbar-nav float-right">
                        
                        <?php $image= $row['photo'];
								?>
                            <a class="nav-link dropdown-toggle text-muted waves-effect waves-dark pro-pic" href="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
							<?php echo '
								<img src=" ../uploads/'.$image.'" alt="user" class="rounded-circle" width="33"></a>'; ?>
                            <div class="dropdown-menu dropdown-menu-right user-dd animated">
                                <a class="dropdown-item" href="admin_pages-profile.php"><i class="ti-email m-r-5 m-l-5"></i> Change Password</a>
                                <a class="dropdown-item" href="logout.php"><i class="ti-wallet m-r-5 m-l-5"></i> Log out</a>
                            </div>
                        </li>
                       
                    </ul>
                </div>
            </nav>
        </header>
        
        <aside class="left-sidebar" data-sidebarbg="skin5">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="index.php" aria-expanded="false">
                                <i class="mdi mdi-av-timer"></i>
                                <span class="hide-menu">Dashboard</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_pages-profile.php" aria-expanded="false">
                                <i class="mdi mdi-account-network"></i>
                                <span class="hide-menu">Profile</span>
                            </a>
                        </li>
                         
                        
                       <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_employee.php" aria-expanded="false">
                                <i class="mdi mdi-face"></i>
                                <span class="hide-menu">Employee</span>
                            </a>
                        </li>
						
						
						<li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_package_add.php" aria-expanded="false">
                                <i class="mdi mdi-arrange-bring-forward"></i>
                                <span class="hide-menu">Spa Packages</span>
                            </a>
                        </li>
						<li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_stock_table.php" aria-expanded="false">
                                <i class="mdi mdi-border-none"></i>
                                <span class="hide-menu">Spa Products </span>
                            </a>
                        </li>
						<li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_employee_leave.php" aria-expanded="false">
                                <i class="mdi mdi-alert-outline"></i>
                                <span class="hide-menu">Leave Requests</span></a>
								</li>
							
                      
							<li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_payment_view.php" aria-expanded="false">
                                <i class="mdi mdi-alert-outline"></i>
                                <span class="hide-menu">Product Sales</span>
								</a></li>
								<li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_billing_view.php" aria-expanded="false">
                                <i class="mdi mdi-alert-outline"></i>
                                <span class="hide-menu">Package Billing</span>
								</a></li>
								
								<li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_cust_feedback.php" aria-expanded="false">
                                <i class="mdi mdi-arrange-bring-forward"></i>
                                <span class="hide-menu">Customer Feedback</span>
                            </a>
                        </li>
                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </aside>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-5 align-self-center">
                        <h4 class="page-title">Stock</h4>
                    </div>
                    <div class="col-7 align-self-center"><?php 
if(isset($_GET['Message']))
{
	$error=$_GET['Message'];
	echo "<h4><font color=green >".$error."</font></h4>";
	
}
?>
                        <div class="d-flex align-items-center justify-content-end">
						 
						
						
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item">
                                        <a href="index.php">Beauty</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page">Admin</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Product List</h4>
								
                                    <div class="row icons" id="icons">
									


								<div class="col-sm-12"><br>
							
  <button  class="btn btn-primary btn-sm btn-flat"id="myBtn"><i class="fa fa-plus"></i> New</button>
<?php 
if(isset($_GET['message']))
{
	$error=$_GET['message'];
	echo "<font color=green >".$message."</font>";
	
}
?>
<!-- The Modal -->


<!-- The Modal -->
<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <div class="modal-header">
      <span class="close">&times;</span>
      <h4>Add Products</h4>
    </div>
    <div class="modal-body">
      <form class="form-horizontal form-material" action="ad_stock_action.php" method="POST" enctype="multipart/form-data">
                                    <div class="form-group">
									<table><tr><td><label class="col-md-12">Name</label></td>
                                       
                                            <td><input type="text" name="pro_name"   pattern="[A-Za-z]{1,20}"  title="please insert only letters" required class="form-control form-control-line" >
                                        
									<td><label class="col-md-12">Image</label></td>
                                       
                                            <td><input type="file" name="image" accept=".png, .jpg, .jpeg" required></td>
										<tr><td><label class="col-md-12">Description</label>
                                        
                                           <td> <textarea rows="4" cols="5" class="form-control form-control-line" required name="pro_desc" ></textarea>
                                        
										<td><label class="col-md-12">Price</label></td>
                                       
                                            <td><input type="number" name="pro_price"  required min="1" oninput="validity.valid||(btnadd='');" class="form-control form-control-line" >
											<tr><td><label class="col-md-12">Expiry</label></td>
                                       
                                            <td><input type="date" name="pro_date" min="<?php echo date('Y-m-d');?>" required class="form-control form-control-line" >
                                        
									<td><label class="col-md-12">Quantity In</label></td>
                                       
                                            <td><input type="number" name="pro_quantity" required class="form-control form-control-line" min="5" oninput="validity.valid||(btnadd='');" >
											
											</td>
											<tr><td><label class="col-md-12">Type</label></td>
                                       
                                            <td><select name="pro_company"  required class="form-control form-control-line" >
											<option name="opt1" value="Skin Care">Skin Care</option>
											<option name="opt2" value="Hair Care">Hair Care</option>
											
											</select>
											</tr>
											</table>
                                        <br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
										&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
										  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <button type="submit" class="btn btn-primary btn-flat" name="btnadd" style="align:right"><i class="fa fa-save"></i> Save</button>
											
                                        </div>
										</div>
																				</form>
    </div>
    
  </div>

</div>

</div>


  
                
				 <div class="col-lg-8 col-xlg-9 col-md-7">
				 
                        <div class="card">
                          <div class="card-body">
							<table class="table">
                <thead class="thead-light">
				<th>Id</th>
                  <th>Name</th>
				  <th>Company</th>
                  <th>Photo</th>
                  <th>Description</th>
                  <th>Price</th>
                  <th>Expiry Date </th>
				  <th>Stock Available</th>
               <th>Action</th>
                </thead>
                <tbody>
                  <?php
                    
$select="select * from tbl_products";
$view=mysql_query($select,$conn);
while($row2=mysql_fetch_array($view))
{
$id_pro=$row2['pro_id'];
$name=$row2['pro_name'];
$cname=$row2['company'];

$photo=$row2['pro_photo'];
$description=$row2['description'];
$price=$row2['pro_price'];
$balance=$row2['pro_quantity'];
$expiry=$row2['expiry_date'];
                      echo"	
					  <form method='POST' action='ad_stock_action.php' enctype='multipart/form-data'>
                          <tr>
						  <td>".$id_pro."</td>
                            <td>".$name."</td>
							
                            <td>".$cname."</td>
                            <td>
								<img src='../uploads/".$photo."'   width='36px' height='36px'/>
								
                              
                            
                            </td>
                            <td><textarea name='pro_desc'  rows='5' cols='8' >".$description."</textarea>
                            
                            
                            </td>
                            <td style='width:50px'><input type='text' name='pro_price' size='5'value=' ".$price."'></td>
                            <td><input type='date' name='pro_date' size='8'  value='".$expiry."'></td>
							<td><input type='text' name='pro_quantity' size='5' value='".$balance."'></td>
                            <td>
                            <input type='hidden' name='id' value=".$id_pro.">
                       <button  type='submit'class='btn btn-primary btn-sm btn-flat' name='btnedit'> <i class='fa fa-edit'></i> Edit</button>
				   <button type='submit' class='btn btn-danger btn-sm delete btn-flat' name='btndelete' ><i class='fa fa-trash'></i> Delete</button>
							  
                            </form> </td>
                          </tr>
                        ";
                  
}
                  ?>
                </tbody>
              </table>
							</div>	<div></div>
              
        
	
	 
</div>
    <script>
	var modal = document.getElementById('myModal');

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on the button, open the modal 
btn.onclick = function() {
    modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
}}
 
var date = new Date();

var day = date.getDate();
var month = date.getMonth() + 1;
var year = date.getFullYear();

if (month < 10) month = "0" + month;
if (day < 10) day = "0" + day;

var today = year + "-" + month + "-" + day;


 

</script>
    <script src="../../assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="../../assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="../../assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="../../assets/extra-libs/sparkline/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="../../dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="../../dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="../../dist/js/custom.min.js"></script>

    

</div>
<!-- ./wrapper -->



 
</body>

</html>
<?php
}
	else
		{
			
			header("location:../ltr/navuser.php?error=wrong password");
		}
?>