<?php
$conn=@mysql_connect("localhost","root","") or die('unable to connect');
//echo "connected"; 
@mysql_select_db("dbvcare",$conn) or die('could not find db');
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<title>Beauty</title>
	<!-- Meta Tags -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="utf-8">
	<meta name="keywords" content="Gleam Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
	<script>
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!-- //Meta Tags -->
	<!-- Style-sheets -->
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" property="" />
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
	<link rel="stylesheet" href="css/lightbox.css">
	<link href="css/fontawesome-all.css" rel="stylesheet">
	<!--// Style-sheets -->
	<!--web-fonts-->
	<link href="//fonts.googleapis.com/css?family=Poiret+One" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
	<!--//web-fonts-->
	<style>
	input[type=text], input[type=password],input[type=email] {
    width:50%;
height:40px;
border-radius:15px 0 15px 0;
border:1px solid #000;
margin-bottom:15px;

color:#000;
}

/* Set a style for all buttons */
button {
display:inline-block;
height:40px;
width:130px;
line-height:40px;
overflow:hidden;
position:relative;
text-align:center;
background:	#9932CC;
border-radius:25px;
color:#fff;

margin-top:20px;
<!--margin-top:20px;-->
}
button-text{
display:block;
height:100%;
position:relative;
top:0;
width:90%;
}
	
}
</style>
</head>

<body>
	 <!--banner -->
	<div class="top-bar_sub container-fluid p-3">
		<div class="row">
			<div class="col-sm-8 top-mid">
				<p class="paragraph-agileinfo">
					<i class="fas fa-map-marker-alt"></i> Thazhe chovva , kannur , Kerala </p>
				<p class="paragraph-agileinfo">
					<i class="fas fa-phone"></i> +91-8281177379</p>
			</div>
			<div class="col-sm-4 log-icons text-right">
 <?php 
if(isset($_GET['Success']))
{
	$error=$_GET['Success'];
	echo "<font color=green >".$error."</font>";
	
}
?>

<?php 
if(isset($_SESSION['u_type']))
	{
					 
echo "<h4><font color=#330066>Hello &nbsp;".$_SESSION['u_name'];"</h4></font>";
	}
?>
				
			</div>
		</div>
	</div>
	<div class="banner" id="home">
		<!-- header -->
		<header>
			<nav class="navbar navbar-expand-lg navbar-light bg-light top-header">
				<h1 class="logo">
					<a class="navbar-brand" href="navuser.php">
						<i class="fab fa-viadeo"></i>Beauty</a>
				</h1>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
				    aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>

				<div class="collapse navbar-collapse" id="navbarSupportedContent">
					<ul class="navbar-nav ml-auto">
						<li class="nav-item active">
							<a class="nav-link ml-lg-0" href="navuser.php">Home
								<span class="sr-only">(current)</span>
							</a>
						</li>
						
				<!--		<li class="nav-item">
							<button  class="nav-link scroll" style="background:transparent" onclick="location.href='../ltr/product.php';" style="width:auto;">Services</button>
						</li>-->
						</ul>
						</div>
						</div>
						<br><br><br><br><br>
						
						<div class="mid-pop">
                                <form  action="forgot_action.php" method="POST" enctype="multipart/form-data">
								<div div style="width:500px; margin:0 auto;">
								<div class="mid-pop">
                                    <div >
                                        <label>Your Mail</label>
                                        <div>
                                            <input type="email"  name="mail" pattern="[a-z0-9._%+-]+@(?=gmail.com|hotmail.com)[a-z0-9.-]+\.[a-z]{2,}$"  required>
                                        </div>
										<?php 
if(isset($_GET['error']))
{
	$error=$_GET['error'];
	echo "<font color=red >".$error."</font>";
	
}
?>
										 </div>
                                   
                                       
                                       
                                            <button class="btn btn-success">Send OTP</button>
                                      
                                </form>
								</div>
						</div>
						</div>
						
						<!--
										<section class="contact-section py-5" id="contact">
		<div class="container py-xl-5 py-sm-3">
			<h5 class="main-w3l-title mb-sm-4 mb-3">Contact Us</h5>
			<div class="row">
				<div class="col-lg-8 wthree_contact_left">
					<h3 class="subheading-wthree mb-md-4 mb-3">Send us an Email</h3>
					<form action="../ltr/contact_action.php" method="POST">
						<div class="form-row">
							<div class="form-group col-md-6">
								<input type="text" class="form-control" placeholder="Name" name="cust_name" required="">
							</div>
							<div class="form-group col-md-6">
								<input type="text" class="form-control" placeholder="phone" name="cust_phone" required="">
							</div>
							<div class="form-group col-md-6">
								<input type="email" class="form-control" placeholder="Email" name="cust_email"required="">
							</div>
							<div class="form-group col-md-6">
								<input type="text" class="form-control" placeholder="Subject" name="subject" required="">
							</div>
						</div>
						<div class="form-group">
							<textarea id="textarea" placeholder="Message..." name="message" required=""></textarea>
						</div>
						<button type="submit" class="btn btn-primary py-sm-3 py-2 px-5">Submit</button>
					</form>
				</div>
				<div class="col-lg-4 wthree_contact_right mt-lg-0 mt-sm-5 mt-4">
					<h3 class="subheading-wthree mb-md-4 mb-3">Get In Touch</h3>
					<address>
						<p class="paragraph-agileinfo mb-md-4 mb-3">
							<i class="fas fa-map-marker-alt mr-3"></i>Vcare beauty spa,thazhe chovva, kannur, kerala, India</p>

						<p class="paragraph-agileinfo mb-md-4 mb-3">
							<i class="fas fa-phone mr-3"></i> +91-8281177576</p>

						<p class="paragraph-agileinfo mb-md-4 mb-3">
							<i class="fas fa-fax mr-3"></i> 0460-229154</p>

						<p class="paragraph-agileinfo">
							<i class="far fa-envelope mr-3"></i>
							<a href="mailto:info@example.com">beauty@gmail.com</a>
						</p>
					</address>
				</div>
			</div>
		</div>
	</section>

	<!-- contact 

	<div class="map-section">
		<iframe src="https://maps.google.com/maps?q=india%20kannur%20thazhe%20chovva%20fair%20touch%20beauty%20parlour%20and%20saloon&t=&z=13&ie=UTF8&iwloc=&output=embed"></iframe>
	</div>
	<footer class="footer-section">
		<div class="container">
			<div class="footer-right py-5">
				<div class="row">
					<div class="col-lg-6 col-md-6 footer-grids">
						<h2>About Us</h2>
						<p class="paragraph-agileinfo">Team momentum and excitement are infectious. 
						Teamwork pulls people together in the most positive and inspiring way.</p>
					</div>
					<div class="col-lg-3 footer-grids mt-lg-0 mt-4">
						<h3>Usefull Links</h3>
						<ul class="w3agile_footer_grid_list">
							<li>
								<a href="navuser.php">Home</a>
							</li>
							<li>
								<a href="#about" class="scroll">About</a>
							</li>
							<li>
								<a href="#gallery" class="scroll">Gallery</a>
							</li>
							<li>
								<a href="#services" class="scroll">Services</a>
							</li>
							<li>
								<a href="#contact" class="scroll">Contact</a>
							</li>
						</ul>
					</div>
					<!--<div class="col-lg-3 footer-grids mt-lg-0 mt-4">
						<h3>Social Media</h3>
						<ul class="social_list1">
							<li class="text-center">
								<a href="#" class="facebook1">
									<i class="fab fa-facebook-f"></i>

								</a>
							</li>
							<li class="text-center mx-sm-3 mx-2">
								<a href="#" class="twitter2">
									<i class="fab fa-twitter"></i>

								</a>
							</li>
							<li class="text-center">
								<a href="#" class="dribble3">
									<i class="fab fa-dribbble"></i>
								</a>
							</li>
						</ul>
					</div>-->
				</div>
			</div>
		</div>
	</footer>
	
	<!-- Required common Js -->
	<script src='js/jquery-2.2.3.min.js'></script>
	<!-- //Required common Js -->
	<!-- flexSlider -->
	<script defer src="js/jquery.flexslider.js"></script>
	<script>
		$(window).load(function () {
			$('.flexslider').flexslider({
				animation: "slide",
				start: function (slider) {
					$('body').removeClass('loading');
				}
			});
		});
	</script>

	<!-- //flexSlider -->

	<!--light-box-files -->
	<script src="js/lightbox-plus-jquery.min.js">
	</script>
	<!--//light-box-files -->


	<!-- start-smoth-scrolling -->
	<script src="js/move-top.js"></script>
	<script src="js/easing.js"></script>
	<script>
		jQuery(document).ready(function ($) {
			$(".scroll").click(function (event) {
				event.preventDefault();
				$('html,body').animate({
					scrollTop: $(this.hash).offset().top
				}, 1000);
			});
		});
	</script>
	<!-- start-smoth-scrolling -->
	<!-- here stars scrolling icon -->
	<script>
		$(document).ready(function () {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear'
				};
			*/

			$().UItoTop({
				easingType: 'easeOutQuart'
			});

		});
	</script>
	<!-- //here ends scrolling icon -->
	<!-- Js for bootstrap working-->
	<script src="js/bootstrap.min.js"></script>
	<!-- //Js for bootstrap working -->
</body>

</html>