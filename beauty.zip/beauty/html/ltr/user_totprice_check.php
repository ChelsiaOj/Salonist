<?php
session_start();
$conn=@mysql_connect("localhost","root","") or die('unable to connect');

@mysql_select_db("dbvcare",$conn) or die('could not find db');

$sname=$_GET["tot_price"];
$sql1="select pack_price from tbl_packages where pack_name='".$sname."' ";
$result1 = mysql_query($sql1);
$row=mysql_fetch_array($result1);
$sPrice=$row['pack_price'];
echo $sPrice;
?>