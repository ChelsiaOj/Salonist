<?php
include("../ltr/dbconnect.php");
session_start();

if(isset($_POST['btncart']))
{
$id=$_POST['prod_id'];
$cust_id=$_SESSION['u_id'];
$stmt="insert into tbl_cart (`cust_id`,`product_id`) values ('$cust_id','$id')";
mysql_query("$stmt",$conn);
header("location:../ltr/product.php?Success=Product Added to cart !");
}

if(isset($_POST['btnremove']))
{
	$c_id=$_POST['cart_id'];
	$id=$_POST['prod_id'];
	$cust_id=$_SESSION['u_id'];
$stmt="delete from tbl_cart where cart_id='$c_id'";
mysql_query("$stmt",$conn);
header('location:../ltr/pro_cart.php');

}
	

?>
