<?php
$conn=@mysql_connect("localhost","root","") or die('unable to connect');
//echo "connected"; 
@mysql_select_db("dbvcare",$conn) or die('could not find db');


$email=$_POST['sub_email'];

$query="INSERT INTO `tbl_subscribe`(`mail_id`) VALUES('$email')";
$result=mysql_query("$query",$conn);

	header("location:../ltr/navuser.php");


?>