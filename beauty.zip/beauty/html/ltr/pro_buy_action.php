<?php
session_start();
$conn=@mysql_connect("localhost","root","") or die('unable to connect');

@mysql_select_db("dbvcare",$conn) or die('could not find db');
if(isset($_POST['pay']))
{
$c_id=$_SESSION['u_id'];
$pro_id=$_POST['pro_id'];
$qty=$_POST['pro_num'];
$actual=$_POST['pro_qty'];
$price=$_POST['pro_price'];
$mode=$_POST['pay_mode'];
$shipping=$_POST['pro_shipping'];
$date = date('Y-m-d');

			$query="INSERT INTO `tbl_prod_bought`(`cust_id`,`pro_id`,`mode`, `price`,`qty`,`date`,`ship_address`) 
							VALUES('$c_id','$pro_id','$mode','$price','$qty','$date','$shipping')";
				
			mysql_query("$query",$conn);
			$sql="update tbl_products  set pro_quantity=$actual-$qty where pro_id=$pro_id";
			mysql_query("$sql",$conn);
			
			//$sql1="update  tbl_address set ship_address='$shipping'";
			//mysql_query("$sql1",$conn);
			
}
	header("location:../ltr/user_account.php?Message=Transaction Successful !");
?>
