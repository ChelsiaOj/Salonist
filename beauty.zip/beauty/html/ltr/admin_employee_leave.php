<?php
include("../ltr/dbconnect.php");
session_start();
$u_id=$_SESSION['u_id'];
$u_pass=$_SESSION['u_pass'];
$u_type=$_SESSION['u_type'];
$sql="select * from tbl_login where u_id='$u_id'  and u_password='$u_pass' ";
$result=mysql_query($sql,$conn);
$row1=mysql_fetch_array($result);
$rowcount=mysql_num_rows($result);
$sql1="select * from tbl_u_detail where u_id='$u_id' ";
$result1=mysql_query($sql1,$conn);
$row=mysql_fetch_array($result1);
if($rowcount==1 && $u_type=="admin")
{
?>



<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="../../assets/images/favicon.png">
    <title>Beauty</title>
    <!-- Custom CSS -->
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" property="" />
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
	<link rel="stylesheet" href="css/lightbox.css">
	<link href="css/fontawesome-all.css" rel="stylesheet">
    <link href="../../dist/css/style.min.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body>
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper" data-navbarbg="skin6" data-theme="light" data-layout="vertical" data-sidebartype="full" data-boxed-layout="full">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <header class="topbar" data-navbarbg="skin6">
            <nav class="navbar top-navbar navbar-expand-md navbar-light">
                <div class="navbar-header" data-logobg="skin5">
                    <!-- This is for the sidebar toggle which is visible on mobile only -->
                    <a class="nav-toggler waves-effect waves-light d-block d-md-none" href="javascript:void(0)">
                        <i class="ti-menu ti-close"></i>
                    </a>
                    <!-- ============================================================== -->
                    <!-- Logo -->
                    <!-- ============================================================== -->
					<div class="navbar-brand">
					<h1 class="logo">
					<a class="navbar-brand" href="index.php">
						<i class="fab fa-viadeo"></i>Beauty</a>
				</h1>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
				    aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
                  <!--  <div class="navbar-brand">
                        <a href="index.html" class="logo">
                            <!-- Logo icon 
                            <b class="logo-icon">
                                <!--You can put here icon as well // <i class="wi wi-sunset"></i> //-->
                                <!-- Dark Logo icon 
                                <img src="../../assets/images/logo-icon.png" alt="homepage" class="dark-logo" />
                                <!-- Light Logo icon 
                                <img src="../../assets/images/logo-light-icon.png" alt="homepage" class="light-logo" />
                            </b>
                            <!--End Logo icon 
                            <!-- Logo text 
                            <span class="logo-text">
                                <!-- dark Logo text 
                                <img src="../../assets/images/logo-text.png" alt="homepage" class="dark-logo" />
                                <!-- Light Logo text 
                                <img src="../../assets/images/logo-light-text.png" class="light-logo" alt="homepage" />
                            </span>
                        </a>-->
                    </div>
                    <!-- ============================================================== -->
                    <!-- End Logo -->
                    <!-- ============================================================== -->
                    <!-- ============================================================== -->
                    <!-- Toggle which is visible on mobile only -->
                    <!-- ============================================================== -->
                    <a class="topbartoggler d-block d-md-none waves-effect waves-light" href="javascript:void(0)" data-toggle="collapse" data-target="#navbarSupportedContent"
                        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="ti-more"></i>
                    </a>
                </div>
                <!-- ============================================================== -->
                <!-- End Logo -->
                <!-- ============================================================== -->
                <div class="navbar-collapse collapse" id="navbarSupportedContent" data-navbarbg="skin6">
                    <!-- ============================================================== -->
                    <!-- toggle and nav items -->
                    <!-- ============================================================== -->
                    <ul class="navbar-nav float-left mr-auto">
					<?php
echo "<h4><font color=#330066>Hello &nbsp;".$_SESSION['u_name'];"</h4></font>"
?>
                        <!-- ============================================================== -->
                        <!-- Search -->
                        <!-- ============================================================== -->
                    <!--    <li class="nav-item search-box">
                            <a class="nav-link waves-effect waves-dark" href="javascript:void(0)">
                                <div class="d-flex align-items-center">
                                    <i class="mdi mdi-magnify font-20 mr-1"></i>
                                    <div class="ml-1 d-none d-sm-block">
                                        <span>Search</span>
                                    </div>
                                </div>
                            </a>
                            <form class="app-search position-absolute">
                                <input type="text" class="form-control" placeholder="Search &amp; enter">
                                <a class="srh-btn">
                                    <i class="ti-close"></i>
                                </a>
                            </form>
                        </li>-->
                    </ul>
                    <!-- ============================================================== -->
                    <!-- Right side toggle and nav items -->
                    <!-- ============================================================== -->
					
                    <ul class="navbar-nav float-right">
                        <!-- ============================================================== -->
                        <!-- User profile and search -->
                        <!-- ============================================================== -->
                      
                            <a class="nav-link dropdown-toggle text-muted waves-effect waves-dark pro-pic" href="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
							<img src=" images/b-arrow.png" alt="user" class="rounded-circle" width="31"></a>
                            <div class="dropdown-menu dropdown-menu-right user-dd animated">
                                <a class="dropdown-item" href="admin_pages-profile.php"><i class="ti-email m-r-5 m-l-5"></i> Change Password</a>
                                <a class="dropdown-item" href="logout.php"><i class="ti-wallet m-r-5 m-l-5"></i> Log out</a>
                            </div>
                        </li>
                        <!-- ============================================================== -->
                        <!-- User profile and search -->
                        <!-- ============================================================== -->
                    </ul>
                </div>
            </nav>
        </header>
        <!-- ============================================================== -->
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <aside class="left-sidebar" data-sidebarbg="skin5">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="index.php" aria-expanded="false">
                                <i class="mdi mdi-av-timer"></i>
                                <span class="hide-menu">Dashboard</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_pages-profile.php" aria-expanded="false">
                                <i class="mdi mdi-account-network"></i>
                                <span class="hide-menu">Profile</span>
                            </a>
                        </li>
                         <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_employee.php" aria-expanded="false">
                                <i class="mdi mdi-face"></i>
                                <span class="hide-menu">Employee</span>
                            </a>
                        </li>
						
						<li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_package_add.php" aria-expanded="false">
                                <i class="mdi mdi-arrange-bring-forward"></i>
                                <span class="hide-menu">Salon Packages</span>
                            </a>
                        </li>
						
						<li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_employee_leave.php" aria-expanded="false">
                                <i class="mdi mdi-arrange-bring-forward"></i>
                                <span class="hide-menu">Leave Requests</span></a>
								</li>
							
                      
						<!--	<li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_payment_view.php" aria-expanded="false">
                                <i class="mdi mdi-alert-outline"></i>
                                <span class="hide-menu">Package Sales</span>
								</a></li>
								<li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_billing_view.php" aria-expanded="false">
                                <i class="mdi mdi-arrange-bring-forward"></i>
                                <span class="hide-menu">Sales</span>
								</a></li>
								<li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_salary.php" aria-expanded="false">
                                <i class="mdi mdi-arrange-bring-forward"></i>
                                <span class="hide-menu">Salary</span>
								</a></li>
							<!--	
								<li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_cust_feedback.php" aria-expanded="false">
                                <i class="mdi mdi-arrange-bring-forward"></i>
                                <span class="hide-menu">Customer Feedback</span>
                            </a>
                        </li>-->
                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </aside>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-5 align-self-center">
                        <h4 class="page-title"> </h4>
                    </div>
                    <div class="col-7 align-self-center">
                        <div class="d-flex align-items-center justify-content-end">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item">
                                        <a href="index.php">Beauty</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page"> Admin</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
				
				
				<div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
							<?php
                    
$select="select * from tbl_leave where status='0' order by date desc ";
$view=mysql_query($select,$conn);
$count=mysql_num_rows($view);
if($count!=0)
{
	?>
                                <h4 class="card-title">Leave Requests</h4>
								
                                   <table class="table">
                <thead class="thead-light">
			
                  <th>Name</th>
				   <th>Designation</th>
				  <th>Reason</th>
                  <th>Date</th>
                  <th>Section</th>
                  <th>Status</th>
				  <th>Action</th>
                  
                </thead>
				<tbody>
				
            <?php     
                  
while($row2=mysql_fetch_array($view))
{
	$id=$row2['l_id'];
	$id_pro=$row2['emp_id'];
	$reason=$row2['reason'];
$date=$row2['date'];
$section=$row2['section'];
$status=$row2['status'];
if($status==1)
{
	$l_status="approved";
}
else if($status==0)
{
	$l_status="pending";
}
else 
{
	$l_status="rejected";
}
      

$select1="select * from tbl_u_detail where u_type=3 && u_id='$id_pro'";

$view1=mysql_query($select1,$conn);


while($row3=mysql_fetch_array($view1))
{

$dbname=$row3['Fname'];
$name=$row3['Lname'];
$emp_desig=$row3['designation'];

//$date_select="select emp_id from tbl_leave where date='$date'";
//$date_s=mysql_query($date_select,$conn);
//$row4=mysql_fetch_array($date_s);
//$emp_lid=$row4['emp_id'];

                      echo"	
					  <form method='POST' action='ad_leave_action.php' enctype='multipart/form-data'>
                          <tr>
						  
                            <td>".$dbname." &nbsp;&nbsp;".$name."</td>
							<td>".$emp_desig."</td>
                            <td>".$reason."</td>
                            
                            <td>".$date."</td>
                            <td>".$section."</td>
							
							<td>".$l_status."</td>
                            <td>
                            <input type='hidden' name='id' value=".$id.">
                       <button  type='submit'class='btn btn-primary btn-sm btn-flat' name='btnapprove'> <i class='fa fa-save'></i> Approve</button>
								
								  <button type='submit' class='btn btn-danger btn-sm delete btn-flat' name='btndecline' ><i class='fa fa-trash'></i> Decline</button>
							  
                            </td>
                          </tr> 
						
						  
						  </form>
                        ";
}          
}


                  ?>
                </tbody>
              </table>		
			
			  </div>
			     
			  
							</div>
						
							
							
							
							
							<?php
}
			  else 
{
	
	echo"<h4> no leave requests</h4>";
}
			  ?>
						</div>
					</div>
					
					
	<!--<button class='btn btn-success' name="btn_date">Details</button>-->
	
	<?php
	
	$sql_get="select * from tbl_leave where status='pending'";
	$view_get=mysql_query($sql_get,$conn);
	$count_get=mysql_num_rows($view_get);
	if($count_get!=0)
{
	while($row3_get=mysql_fetch_array($view_get))
{

$db_date=$row3_get['date'];

$sql_get_date="select emp_id from tbl_leave where status='approved' and date='db_date'";
	$view_get_date=mysql_query($sql_get_date,$conn);
	$count_get_date=mysql_num_rows($view_get_date);
	if($count_get_date!=0)
{
	while($row3_get_date=mysql_fetch_array($view_get_date))
	{
		$emp_desig=$row3_get_date['designation'];
		
		$sel_emp="select designation from tbl_u_detail where u_type=3 && u_id='$emp_desig'";

		$view_emp=mysql_query($sel_emp,$conn);
		$get=mysql_fetch_array($view_emp);


	}
}
}

}
	?>
				
								
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
            </div>
			
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
        <!--    <footer class="footer text-center">
                All Rights Reserved by Nice admin. Designed and Developed by
                <a href="https://wrappixel.com">WrapPixel</a>.
            </footer>
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
  
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="../../assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="../../assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="../../assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="../../assets/extra-libs/sparkline/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="../../dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="../../dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="../../dist/js/custom.min.js"></script>
</body>

</html>
<?php
}
	else
		{
			
			header("location:../ltr/navuser.php?error=wrong password");
		}
?>