<?php
include("../ltr/dbconnect.php");
session_start();
$u_id=$_SESSION['u_id'];
$u_pass=$_SESSION['u_pass'];
$u_type=$_SESSION['u_type'];
$sql="select * from tbl_login where u_id='$u_id'  and u_password='$u_pass' ";
$result=mysql_query($sql,$conn);
$rowcount=mysql_num_rows($result);
$sql1="select * from tbl_u_detail where u_id='$u_id' ";
$result1=mysql_query($sql1,$conn);
$row=mysql_fetch_array($result1);
$sql2="select * from tbl_address where u_id='$u_id' ";
$result2=mysql_query($sql2,$conn);
$row2=mysql_fetch_array($result2);
if($rowcount==1 && $u_type=="User")
{
?>

<!DOCTYPE html>
<html>
<head>
<title>Beauty</title>
<link href="css1/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<!--theme-style-->
<link href="css1/style.css" rel="stylesheet" type="text/css" media="all" />	

<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Shopin Responsive web template, Bootstrap Web Templates, Flat Web Templates, AndroId Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--theme-style-->

<link href="css1/style4.css" rel="stylesheet" type="text/css" media="all" />	
<!--//theme-style-->
<script src="js1/jquery.min.js"></script>
<!--- start-rate---->
<script src="js1/jstarbox.js"></script>
	<link rel="stylesheet" href="css1/jstarbox.css" type="text/css" media="screen" charset="utf-8" />
		<script type="text/javascript">
			jQuery(function() {
			jQuery('.starbox').each(function() {
				var starbox = jQuery(this);
					starbox.starbox({
					average: starbox.attr('data-start-value'),
					changeable: starbox.hasClass('unchangeable') ? false : starbox.hasClass('clickonce') ? 'once' : true,
					ghosting: starbox.hasClass('ghosting'),
					autoUpdateAverage: starbox.hasClass('autoupdate'),
					buttons: starbox.hasClass('smooth') ? false : starbox.attr('data-button-count') || 5,
					stars: starbox.attr('data-star-count') || 5
					}).bind('starbox-value-changed', function(event, value) {
					if(starbox.hasClass('random')) {
					var val = Math.random();
					starbox.next().text(' '+val);
					return val;
					} 
				})
			});
		});
		</script>

<!---//End-rate---->
<link href="css1/form.css" rel="stylesheet" type="text/css" media="all" />

<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}

#table {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#table td, #table th {
  border: 1px solid #7990b5;
  padding: 8px;
}

#table tr:nth-child(even){background-color: #f2f2f2;}

#table tr:hover {background-color: #ddd;}

#table th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #7990b5;
  color: white;
}

</style>

</head>
<body>
<!--header-->
<div class="header">
<div class="container">
		<div class="head">
			<div class=" logo">
				
			</div>
		</div>
	</div>
	
		
		<div class="container">
		
			<div class="head-top">
			
		 <div class="col-sm-8 col-md-offset-2 h_menu4">
				<nav class="navbar nav_bottom" role="navigation">
 
 <!-- Brand and toggle get grouped for better mobile display -->
  <div class="navbar-header nav_2">
      <button type="button" class="navbar-toggle collapsed navbar-toggle1" data-toggle="collapse" data-target="#bs-megadropdown-tabs">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
     
   </div> 
   <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-megadropdown-tabs">
        <ul class="nav navbar-nav nav_1">
           <li><a class="color" href="navuser.php">Beauty</a></li>
            
 
 <li><a class="color3" href="product.php">Services</a></li>
 <li><a class="color3" href="user_booking_availablity.php">Book Now</a></li>
 <?php
 if(isset($_SESSION['u_type']))
				 {
					 ?>
 <li><a class="color5" href="user_history.php">My Account</a></li>
            
			<li><a class="color5" href="user_profile.php">Profile</a></li>
				 <?php 
				 
				 }
				 ?>
        </ul>
     </div><!-- /.navbar-collapse -->

</nav>
			</div>
			
			<div class="col-sm-2 search-right">
				<ul class="heart"><?php
				
				
				 if(isset($_SESSION['u_type']))
				 {
					 ?>
				<li>  <?php
echo "<h4><font color=#330066>Hello &nbsp;".$_SESSION['u_name'];"</h4></font>"
?></li>
				
				
				<li ><a class="color6" href="../ltr/logout.php">Logout</a></li>
				
				<?php
				
				 }
				 else{ 
					 ?>
					 <li ><a class="color6" href="navuser.php">Login</a></li>
				<li ><a class="color6" href="navuser.php">Register</a></li>
				<?php
				 }
				 ?>
					</ul>
					
					 <div class="total">
				
      
						
						 
							
							<!--<img src="images/cart.png" alt=""/></h3>
						
						<p><a href="javascript:;" class="simpleCart_empty">Empty Cart</a></p>-->

					</div>
					<div class="clearfix"> </div>
					
						<!----->

						<!---pop-up-box---->					  
			<link href="css1/popuo-box.css" rel="stylesheet" type="text/css" media="all"/>
			<script src="js1/jquery.magnific-popup.js" type="text/javascript"></script>
			<!---//pop-up-box---->
			<div id="small-dialog" class="mfp-hide">
				<div class="search-top">
					<div class="login-search">
						<input type="submit" value="">
						<input type="text" value="Search.." onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search..';}">		
					</div>
					<p>Beauty</p>
				</div>				
			</div>
		 <script>
			$(document).ready(function() {
			$('.popup-with-zoom-anim').magnificPopup({
			type: 'inline',
			fixedContentPos: false,
			fixedBgPos: true,
			overflowY: 'auto',
			closeBtnInside: true,
			preloader: false,
			midClick: true,
			removalDelay: 300,
			mainClass: 'my-mfp-zoom-in'
			});
																						
			});
		</script>		
						<!----->
			</div>
			<div class="clearfix"></div>
		</div>	
	</div>	
</div>
<!--banner-->

<div class="banner-top">
	<div class="container">
		<h1>Beauty</h1>
		<em></em>
		<h2>Profile</h2>
	</div>
</div><br><br>
					
					  <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                    <!-- Column -->
                    <div class="col-lg-4 col-xlg-3 col-md-5">
                        
										<?php 
if(isset($_GET['error']))
{
	$error=$_GET['error'];
	echo "<font color=red >".$error."</font>";
	
}
?> 

<?php

$select="select * from tbl_cust_packages where cust_id='".$_SESSION['u_id']."'";
$get=mysql_query($select,$conn);
$number=mysql_num_rows($get);
if($number!=0)
{

?>
 <h4 class="card-title"><u>HISTORY</u></h4><br>
								
                      <table id="customers">
                <thead >
			
                  <th>Package</th>
				  <th>Date</th>
                  <th>Price</th>
                 
                  
                </thead>
				<tbody>


	<?php 
	while($ans=mysql_fetch_array($get))
{
	$dbPack=$ans['package'];
	$dbDate=$ans['date'];
$dbPrice=$ans['price'];
 echo"	
					
                          <tr>
						  
                            
							
                            <td>".$dbPack."</td>
                            
                            <td>".$dbDate."</td>
                            <td>".$dbPrice."</td>
							</tr>";
							
}

}
else 
{
	echo "no services till now";
}
	?>		
</tbody>	
</table>	
                    </div>
					
                              
									
							
									
                    <!-- Column -->
                    <!-- Column -->
                    
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
          
			
			<div class="col-lg-4 col-xlg-3 col-md-5">
			
			
			
 <h4 class="card-title"><u>UPCOMING BOOKINGS</u></h4><br>
 <?php

$select="select * from tbl_cust_packages where cust_id='".$_SESSION['u_id']."' and booking_status=0";
$get=mysql_query($select,$conn);
$number=mysql_num_rows($get);
if($number!=0)
{

?>
								
                      <table id="table">
                <thead >
			
                  <th>Package</th>
				  <th>Date</th>
                 
                 
                  
                </thead>
				<tbody>


	<?php 
	while($ans=mysql_fetch_array($get))
{
	$dbPack=$ans['package'];
	$dbDate=$ans['date'];
//dbPrice=$ans['price'];
 echo"	
					
                          <tr>
						  
                            
							
                            <td>".$dbPack."</td>
                            
                            <td>".$dbDate."</td>
                            
							</tr>";
							
}

}
else 
{
	echo "Nothing booked to date";
}
	?>		
</tbody>	
</table>	
			
			
			</div>
			
			  </div>
			</div>
					
					<div class="footer">
	<div class="footer-middle">
				<div class="container">
					<div class="col-md-3 footer-middle-in">
						<a href=""><h6>Beauty</h6></a>
						<p>There are loads of anti-aging supplements out there that promise to make you look younger.
					We dove into research and talked to top dermatologists to find the few worth popping.</p>
					</div>
					
					<div class="col-md-3 footer-middle-in">
						<h6>Information</h6>
						<ul class=" in">
							<li><a href="navuser.php">About</a></li>
							<li><a href="navuser.php">Contact Us</a></li>
							
							
						</ul>
						<ul class="in in1">
							<li><a href="user_account.php">Order History</a></li>
							<li><a href="pro_cart.php">Cart</a></li>
							<li><a href="navuser.php">Login</a></li>
						</ul>
						<div class="clearfix"></div>
					</div>
					
					<div class="col-md-3 footer-middle-in">
						<h6>Newsletter</h6>
						<span>Sign up for News Letter</span>
							<form action="../ltr/subscribe_action.php"  method="post">
								<input type="text" name="sub_email" value="Enter your E-mail" onfocus="this.value='';" onblur="if (this.value == '') {this.value ='Enter your E-mail';}">
								<input type="submit" value="Subscribe">	
							</form>
					</div>
					<div class="clearfix"> </div>
				</div>
			</div>
			<div class="footer-bottom">
				<div class="container">
					<ul class="footer-bottom-top">
						<li><img src="images/f1.png" class="img-responsive" alt=""></li>
						<li><img src="images/f2.png" class="img-responsive" alt=""></li>
						<li><img src="images/f3.png" class="img-responsive" alt=""></li>
					</ul>
					
					<div class="clearfix"> </div>
				</div>
			</div>
		</div>
		
		<!--//footer-->
<script src="js1/imagezoom.js"></script>

	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script defer src="js1/jquery.flexslider.js"></script>
<link rel="stylesheet" href="css1/flexslider.css" type="text/css" media="screen" />

<script>
// Can also be used with $(document).ready()
$(window).load(function() {
  $('.flexslider').flexslider({
    animation: "slide",
    controlNav: "thumbnails"
  });
});



</script>

	<script src="js1/simpleCart.min.js"> </script>
<!-- slide -->
<script src="js1/bootstrap.min.js"></script>


</body>
</html>







<?php
}
	else
		{
			
			header("location:../ltr/navuser.php?error=Login failed");
		}
?>
	