<?php
session_start();
$conn=@mysql_connect("localhost","root","") or die('unable to connect');

@mysql_select_db("dbvcare",$conn) or die('could not find db');
if(isset($_POST['btnsave']))
{

$emp_id=$_SESSION['u_id'];

$section=$_POST['l_section'];
$reason=$_POST['l_reason'];
$rawdate = htmlentities($_POST['l_date']);
$leav_date = date('Y-m-d', strtotime($rawdate));
$query="insert into tbl_leave(`emp_id`,`reason`,`date`,`section`,`status`) values ('$emp_id','$reason','$leav_date','$section','0')";
mysql_query("$query",$conn);



	header("location:../ltr/emp_leave.php");
		
			
}



?>



 
