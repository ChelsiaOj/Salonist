<?php

$conn=@mysql_connect("localhost","root","") or die('unable to connect');
@mysql_select_db("dbvcare",$conn) or die('could not find db');
session_start();

$email=$_POST['emp_mail'];
$desig= implode(',', $_POST['desig']);
$query1= mysql_query("insert into tbl_login (`u_id`) VALUES('$email')");
$set=mysql_query("$query1",$conn);
$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%&*_";
$password = substr( str_shuffle( $chars ), 0, 8 );

$query = mysql_query("UPDATE tbl_login SET u_password='$password' WHERE u_id='$email'");
$set1=mysql_query("$query",$conn);
$query3= mysql_query("insert into tbl_u_detail (`u_id`) VALUES('$email')");
$set3=mysql_query("$query3",$conn);
$query2= mysql_query("update tbl_u_detail set`Fname`='Employee', `u_type`=3,`u_status`=1,`designation`='$desig' where u_id='$email' ");
$set2=mysql_query("$query2",$conn);
//$query4= mysql_query("insert into tbl_address (`u_id`) VALUES('$email')");
//$set4=mysql_query("$query4",$conn);

	

 require 'PHPMailer-master/PHPMailerAutoload.php';

$mail = new PHPMailer();

  //Enable SMTP debugging.
  $mail->SMTPDebug = 1;
  //Set PHPMailer to use SMTP.
  $mail->isSMTP();
  //Set SMTP host name
  $mail->Host = "smtp.gmail.com";
  $mail->SMTPOptions = array(
                    'ssl' => array(
                        'verify_peer' => false,
                        'verify_peer_name' => false,
                        'allow_self_signed' => true
                    )
                );
  //Set this to true if SMTP host requires authentication to send email
  $mail->SMTPAuth = TRUE;
  //Provide username and password
  $mail->Username = "chelsiaoj96@gmail.com";
  $mail->Password = "ammuoj170";
  //If SMTP requires TLS encryption then set it
  $mail->SMTPSecure = "tls";
  $mail->Port = 587;
  //Set TCP port to connect to

  //$mail->to = "jomiyajohn@mca.ajce.in";
  //$mail->From = "jomiyajohn@mca.ajce.in";
  //$mail->FromName = "noora";

$mail->addAddress($email);

  $mail->isHTML(true);

  $mail->Subject = "Your Beauty Login credentials";
  $mail->Body = "<i>Use your registered mail and following password to login your accounts:</i>".$password;
  $mail->AltBody = "";
  if(!$mail->send())
   {
      //echo "<script>alert('Authentication not Success Please try again');window.location='forgotpassword.php';</script>";
   //echo "Mailer Error: " . $mail->ErrorInfo;
   header("location:../ltr/admin_employee.php?Message=not send");
  }
  else
  {
	  header("location:../ltr/admin_employee.php?Message=Details sent via email successfully");
      //echo "<script>alert('Authentication Success Please check your mail');window.location='otpconfirm.php';</script>";
   //echo "Message has been sent successfully";
  }
	



?>
