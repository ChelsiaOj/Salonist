<?php
include("../ltr/dbconnect.php");
session_start();
$u_id=$_SESSION['u_id'];
$u_pass=$_SESSION['u_pass'];
$u_type=$_SESSION['u_type'];
$sql="select * from tbl_login where u_id='$u_id'  and u_password='$u_pass' ";
$result=mysql_query($sql,$conn);
$row1=mysql_fetch_array($result);
$rowcount=mysql_num_rows($result);
$sql1="select * from tbl_u_detail where u_id='$u_id' ";
$result1=mysql_query($sql1,$conn);
$row=mysql_fetch_array($result1);
if($rowcount==1 && $u_type=="admin")
{
?>



<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="../../assets/images/favicon.png">
    <title>Beauty</title>
    <!-- Custom CSS -->
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" property="" />
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
	<link rel="stylesheet" href="css/lightbox.css">
	<link href="css/fontawesome-all.css" rel="stylesheet">
    <link href="../../dist/css/style.min.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<style>
.pagination {
  display: inline-block;
}

.pagination a {
  color: black;
  float: left;
  padding: 8px 16px;
  text-decoration: none;
  border: 1px solid #ddd;
}

.pagination a.active {
  background-color: #4CAF50;
  color: white;
  border: 1px solid #4CAF50;
}

.pagination a:hover:not(.active) {background-color: #ddd;}

.pagination a:first-child {
  border-top-left-radius: 5px;
  border-bottom-left-radius: 5px;
}

.pagination a:last-child {
  border-top-right-radius: 5px;
  border-bottom-right-radius: 5px;
}

</style>
<style>
.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    padding-top:0; /* Location of the box */
   top: 15%;
  left: 35%;
 
width: 55%; /* Full width */
    height: 55%; /* Full height */
	<!--margin: 0 auto;-->
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.modal-content {
    position: relative;
    background-color: #fefefe;
    margin: auto;
    padding: 1px;
    border: 1px solid #888;
    width: 100%;
	height:100%;
    box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);
    -webkit-animation-name: animatetop;
    -webkit-animation-duration: 0.4s;
    animation-name: animatetop;
    animation-duration: 0.4s
}

/* Add Animation */
@-webkit-keyframes animatetop {
    from {top:-300px; opacity:0} 
    to {top:0; opacity:1}
}

@keyframes animatetop {
    from {top:-300px; opacity:0}
    to {top:0; opacity:1}
}

/* The Close Button */
.close {
   position: absolute;
    left: 600px;
    top: 0;
    color: #ffffff;
    font-size: 35px;
    font-weight: bold;
}

.close:hover,
.close:focus {
	color: #ffffff;
    cursor: pointer;
    
    text-decoration: none;
    
}

.modal-header {
    /*padding: 2px 16px;*/
    background-color:#8c0073;
    color: white;
}

.modal-body {padding: 10px 16px;}

.checkbox-grid li {
    display: block;
    float: left;
    width: 30%;
}

</style>


<body>
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper" data-navbarbg="skin6" data-theme="light" data-layout="vertical" data-sidebartype="full" data-boxed-layout="full">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <header class="topbar" data-navbarbg="skin6">
            <nav class="navbar top-navbar navbar-expand-md navbar-light">
                <div class="navbar-header" data-logobg="skin5">
                    <!-- This is for the sidebar toggle which is visible on mobile only -->
                    <a class="nav-toggler waves-effect waves-light d-block d-md-none" href="javascript:void(0)">
                        <i class="ti-menu ti-close"></i>
                    </a>
                    <!-- ============================================================== -->
                    <!-- Logo -->
                    <!-- ============================================================== -->
					<div class="navbar-brand">
					<h1 class="logo">
					<a class="navbar-brand" href="index.php">
						<i class="fab fa-viadeo"></i>Beauty</a>
				</h1>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
				    aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
                  
                    </div>
                    
                    <a class="topbartoggler d-block d-md-none waves-effect waves-light" href="javascript:void(0)" data-toggle="collapse" data-target="#navbarSupportedContent"
                        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="ti-more"></i>
                    </a>
                </div>
                <!-- ============================================================== -->
                <!-- End Logo -->
                <!-- ============================================================== -->
                <div class="navbar-collapse collapse" id="navbarSupportedContent" data-navbarbg="skin6">
                    <!-- ============================================================== -->
                    <!-- toggle and nav items -->
                    <!-- ============================================================== -->
                    <ul class="navbar-nav float-left mr-auto">
					<?php
echo "<h4><font color=#330066>Hello &nbsp;".$_SESSION['u_name'];"</h4></font>"
?>
                      
                    </ul>
                    <!-- ============================================================== -->
                    <!-- Right side toggle and nav items -->
                    <!-- ============================================================== -->
					
                    <ul class="navbar-nav float-right">
                        <!-- ============================================================== -->
                        <!-- User profile and search -->
                        <!-- ============================================================== -->
                       
                            <a class="nav-link dropdown-toggle text-muted waves-effect waves-dark pro-pic" href="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
							<img src=" images/b-arrow.png" alt="user" class="rounded-circle" width="31"></a>
                            <div class="dropdown-menu dropdown-menu-right user-dd animated">
                                <a class="dropdown-item" href="admin_pages-profile.php"><i class="ti-email m-r-5 m-l-5"></i> Change Password</a>
                                <a class="dropdown-item" href="logout.php"><i class="ti-wallet m-r-5 m-l-5"></i> Log out</a>
                            </div>
                        </li>
                        <!-- ============================================================== -->
                        <!-- User profile and search -->
                        <!-- ============================================================== -->
                    </ul>
                </div>
            </nav>
        </header>
        <!-- ============================================================== -->
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <aside class="left-sidebar" data-sidebarbg="skin5">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="index.php" aria-expanded="false">
                                <i class="mdi mdi-av-timer"></i>
                                <span class="hide-menu">Dashboard</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_pages-profile.php" aria-expanded="false">
                                <i class="mdi mdi-account-network"></i>
                                <span class="hide-menu">Profile</span>
                            </a>
                        </li>
                         <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_employee.php" aria-expanded="false">
                                <i class="mdi mdi-face"></i>
                                <span class="hide-menu">Employee</span>
                            </a>
                        </li>
						
						<li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_package_add.php" aria-expanded="false">
                                <i class="mdi mdi-arrange-bring-forward"></i>
                                <span class="hide-menu">Salon Services</span>
                            </a>
                        </li>
						
						<li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_employee_leave.php" aria-expanded="false">
                                <i class="mdi mdi-arrange-bring-forward"></i>
                                <span class="hide-menu">Leave Requests</span></a>
								</li>
							
                      
						<!--	<li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_payment_view.php" aria-expanded="false">
                                <i class="mdi mdi-alert-outline"></i>
                                <span class="hide-menu">Package Sales</span>
								</a></li>
								<li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_billing_view.php" aria-expanded="false">
                                <i class="mdi mdi-alert-outline"></i>
                                <span class="hide-menu">Sales</span>
								</a></li>
								<li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_salary.php" aria-expanded="false">
                                <i class="mdi mdi-arrange-bring-forward"></i>
                                <span class="hide-menu">Salary</span>
								</a></li>
							<!--	
								<li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_cust_feedback.php" aria-expanded="false">
                                <i class="mdi mdi-arrange-bring-forward"></i>
                                <span class="hide-menu">Customer Feedback</span>
                            </a>
                        </li>-->
                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </aside>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-5 align-self-center">
                        <h4 class="page-title"> Manage Employee</h4>
                    </div>
                    <div class="col-7 align-self-center">
					<?php 
if(isset($_GET['Message']))
{
	$error=$_GET['Message'];
	echo "<h4><font color=green >".$error."</font></h4>";
	
}
?>
                        <div class="d-flex align-items-center justify-content-end">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item">
                                        <a href="index.php">Beauty</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page"> Admin</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
				
				
                         <div class="row">
						  <div class="col-12">
				
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Add Staff</h4>
                               
                                    <div class="form-group">
								 <form class="form-horizontal form-material" action="admin_gen_password.php" method="POST">
                                        <label class="col-md-12">Email</label>
                                        <div class="col-md-12">
                                            <input type="email" onchange="checkStaff(this.value)" id= "emp_mail"name="emp_mail"  pattern="[a-z0-9._%+-]+@(?=gmail.com|hotmail.com)[a-z0-9.-]+\.[a-z]{2,}$" class="form-control form-control-line" required>
                                        <span id="Msg" ></span>
										</div><br>
										<label class="col-md-12">Salary</label>
                                        <div class="col-md-12">
                                            <input type="int" onchange="validWage(this.value)" name="emp_wages" id="emp_wages"  pattern="" class="form-control form-control-line" required>
                                        </div>
										<br>
										 <label class="col-md-12">Services Handled</label>
                                        <div class="col-md-12">
                                    
											
											 <?php 
				$sql="select pack_name from tbl_packages";
				$res = mysql_query($sql);
			while($list = mysql_fetch_array($res)){
  
				$p_name = $list['pack_name'];
				
				?>
				
							<ul class="checkbox-grid">
							<li> <input type="checkbox" name="desig[]" value="<?php echo $p_name;?>" class="form-control form-control-line"><?php echo $p_name; ?> 
							</li>
							</ul>
			   <?php 
				}
				?>
							
											
                                        </div>
										 <br><br>
										 <div class="form-group">
                                        <div class="col-sm-12"><br>
                                            <button name="btn_generate"class="btn btn-success">Send Mail</button>
                                        </div>
                                    </div>
									
                                </form>
								</div>
				
            </div>
			</div>
			
			</div>
			
            
        </div>
	
				
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title"> Your Staff</h4>
								
                                    <div class="row icons" id="icons">
									

<font color=black>
<center>

<table class="table table-striped"><tr>
<thead class="thead-light">
<th>Photo</th><th>Name</th><th>Id</th><th>Designation</th><th>Salary</th><th>Status</th>
</thead>
</tr>
<?php

 $record_per_page = 4;
$page = '';
if(isset($_GET["page"]))
{
 $page = $_GET["page"];
}
else
{
 $page = 1;
}

$start_from = ($page-1)*$record_per_page;
				  

$next="select * from tbl_u_detail where u_type=3 LIMIT $start_from, $record_per_page";
$see=mysql_query($next,$conn);


while($value=mysql_fetch_array($see))
{
	$dbmail=$value['u_id'];
	$dbdesig=$value['designation'];
$dbname=$value['Fname'];
$dblname=$value['Lname'];
//$dbphno=$value['phone'];
$pic=$value['photo'];
$status=$value['u_status'];
$sql_d="select * from tbl_designation where designation='$dbdesig'";
$res1 = mysql_query($sql_d);
while($list1 = mysql_fetch_array($res1)){
  
$salary = $list1['rate'];


if($status==1)
			{
				$sname="Block";
			}
elseif($status==0) 
			{
				$sname="Unblock";
			}
			




echo "<form action='ad_emp_block.php' value='GET'>";
$tmp="<input type='submit' value='$sname' name='btnstatus'>";
echo "
<tr>
<td> <img src=' ../uploads/$pic' width='50px' height='50px' alt='no image'></td><td> $dbname &nbsp;$dblname</td><td>$dbmail</td><td>$dbdesig</td><td>$salary</td>
 <td>$tmp</td></tr>";
 echo"<input type='hidden' value='$dbmail' name='u_id'>";
 
 echo"</form>";

		}
}
echo "</table>";
echo "</center>";

 ?>
 


</table>
</form>
<div class="pagination" align="center">
    <br />
    <?php
    $page_query = "SELECT count(details_id) FROM tbl_u_detail where u_type='3'";
    $page_result = mysql_query($page_query,$conn);
    $row = mysql_fetch_row($page_result);
	$total_records=$row[0];
    $total_pages = ceil($total_records/$record_per_page);
    
    $pagLink = "<div class='pagination'>";  
for ($i=1; $i<=$total_pages; $i++) {  
             $pagLink .= "<a href='admin_employee.php?page=".$i."'>".$i."</a>";  
};  
echo $pagLink . "</div>";  
?>
    
    
    </div>
                                      
                                    </div>
									 
                            </div>
							
                        </div>
                    </div>
					
                </div>
				
</div>
</div>
  
<script>
	function checkStaff(){
    var staff = document.getElementById('emp_mail');
	
    if(staff != "")
    {	
			//$('#subEdit').prop('enabled', true);
        if (window.XMLHttpRequest)
        {// code for IE7+, Firefox, Chrome, Opera, Safari
          xmlhttp=new XMLHttpRequest();
        }
        else
        {// code for IE6, IE5
          xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange=function()
        {
          if (xmlhttp.readyState==4 && xmlhttp.status==200)
            {
                var value = xmlhttp.responseText;
                if(value >0)
                {
                     document.getElementById('Msg').innerHTML="staff already exists";
					
                  
                }
				
				
                else
                {
                  document.getElementById('').innerHTML="";
                }
            }
          }
        xmlhttp.open("GET","ad_staff_action.php?q="+staff.value,true);
        xmlhttp.send();
    }
	else{
		 document.getElementById('validMsg').innerHTML="please enter a value";
	}
}
	
	
</script>
<script>
function validWage() {
  var x = document.getElementById("emp_rate");
  if(x.value<50)
  {
   document.getElementById('validMsg').innerHTML="please enter wage more than 50 ";
    $('#subEdit').prop('disabled', true);
  }
  
  
}

var date = new Date();

var day = date.getDate();
var month = date.getMonth() + 1;
var year = date.getFullYear();

if (month < 10) month = "0" + month;
if (day < 10) day = "0" + day;

var today = year + "-" + month + "-" + day;


document.getElementById('theDate').value = today;

</script>


    <script src="../../assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="../../assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="../../assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="../../assets/extra-libs/sparkline/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="../../dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="../../dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="../../dist/js/custom.min.js"></script>
</body>

</html>
<?php
}
	else
		{
			
			header("location:../ltr/navuser.php?error=wrong password");
		}
?>