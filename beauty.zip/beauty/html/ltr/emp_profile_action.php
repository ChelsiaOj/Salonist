<?php

$conn=@mysql_connect("localhost","root","") or die('unable to connect');
@mysql_select_db("dbvcare",$conn) or die('could not find db');
session_start();

//$Fname=$_POST['admin_Fname'];
//$Lname=$_POST['admin_Lname'];
//$email=$_POST['admin_mail'];
//$area=$_POST['admin_area'];
//$city=$_POST['admin_city'];
///$pin=$_POST['admin_pincode'];
//$dist=$_POST['admin_dist'];
//$state=$_POST['admin_state'];
$phone=$_POST['admin_phone'];
$question=$_POST['security_q'];
$u_answer=$_POST['answer'];

$query="update tbl_u_detail set `phone`='$phone' where `u_id`='".$_SESSION['u_id']."'";
mysql_query("$query",$conn);
//$_SESSION['u_name'] = $Fname;

//$query1="update tbl_address set `area`='$area',`city`='$city',`pincode`='$pin',`district`='$dist',`state`='$state' where `u_id`='".$_SESSION['u_id']."'";
//mysql_query("$query1",$conn);
$update="UPDATE `tbl_login` SET `security_ques`='$question',`answer`='$u_answer' WHERE`u_id`='".$_SESSION['u_id']."'";
mysql_query("$update",$conn);
//$_SESSION['u_id'] = $email;
header("location:../ltr/emp_pages-profile.php");
	
	

?>
