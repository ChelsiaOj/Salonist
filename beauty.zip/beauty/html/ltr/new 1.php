$("#profileImage").click(function(e) {
$("#imageUpload").click();
});

function fasterPreview( uploader ) {
if ( uploader.files && uploader.files[0] ){
$('#profileImage').attr('src', 
window.URL.createObjectURL(uploader.files[0]) );
}
}

$("#imageUpload").change(function(){
fasterPreview( this );
});
#imageUpload
{
display: none;
}

#profileImage
{
cursor: pointer;
}

#profile-container {
width: 150px;
height: 150px;
overflow: hidden;
-webkit-border-radius: 50%;
-moz-border-radius: 50%;
-ms-border-radius: 50%;
-o-border-radius: 50%;
border-radius: 50%;
}

#profile-container img {
width: 150px;
height: 150px;
}
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<div id="profile-container">
<image id="profileImage" src="http://lorempixel.com/100/100" />
</div>
<input id="imageUpload" type="file" 
name="profile_photo" placeholder="Photo" required="" capture>