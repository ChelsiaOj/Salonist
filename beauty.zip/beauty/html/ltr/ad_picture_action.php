<?php
session_start();



$conn=@mysql_connect("localhost","root","") or die('unable to connect');
 
@mysql_select_db("dbvcare",$conn) or die('could not find db');


$photo=$_FILES['image']['name'];
if(move_uploaded_file($_FILES['image']['tmp_name'],"../uploads/".$photo))
			{
					$query="update `tbl_u_detail` set `photo`='$photo' where `u_id`='".$_SESSION['u_id']."'";
mysql_query("$query",$conn);

			}

header("location:../ltr/admin_pages-profile.php");
?>