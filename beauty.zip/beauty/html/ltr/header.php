<?php
include("../ltr/dbconnect.php");
//echo "i am in header";
?>