<?php
include("../ltr/dbconnect.php");
session_start();
$u_id=$_SESSION['u_id'];
$u_pass=$_SESSION['u_pass'];
$u_type=$_SESSION['u_type'];
$sql="select * from tbl_login where u_id='$u_id'  and u_password='$u_pass' ";
$result=mysql_query($sql,$conn);
$rowcount=mysql_num_rows($result);
$sql1="select * from tbl_u_detail where u_id='$u_id' ";
$result1=mysql_query($sql1,$conn);
$row=mysql_fetch_array($result1);
$sql2="select * from tbl_address where u_id='$u_id' ";
$result2=mysql_query($sql2,$conn);
$row2=mysql_fetch_array($result2);
if($rowcount==1 && $u_type=="admin")
{
?>



<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="../../assets/images/favicon.png">
    <title>profile</title>
	<style>
	<!--.uploadFile {

height: 40px;
width:90px;
overflow:hidden;

}
.uploadFile input {
filter: alpha(opacity=1);
opacity: 1;
margin-right:180px;
}
</style>
    <!-- Custom CSS -->
		<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" property="" />
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
	<link rel="stylesheet" href="css/lightbox.css">
	<link href="css/fontawesome-all.css" rel="stylesheet">
    <link href="../../dist/css/style.min.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body>
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper" data-navbarbg="skin6" data-theme="light" data-layout="vertical" data-sidebartype="full" data-boxed-layout="full">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <header class="topbar" data-navbarbg="skin6">
            <nav class="navbar top-navbar navbar-expand-md navbar-light">
                <div class="navbar-header" data-logobg="skin5">
                    <!-- This is for the sidebar toggle which is visible on mobile only -->
                    <a class="nav-toggler waves-effect waves-light d-block d-md-none" href="javascript:void(0)">
                        <i class="ti-menu ti-close"></i>
                    </a>
                    <!-- ============================================================== -->
                    <!-- Logo -->
                    <!-- ============================================================== -->
                    <div class="navbar-brand">
					<h1 class="logo">
					<a class="navbar-brand" href="index.php">
						<i class="fab fa-viadeo"></i>Beauty</a>
				</h1>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
				    aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
                        
                    </div>
                    
                    <a class="topbartoggler d-block d-md-none waves-effect waves-light" href="javascript:void(0)" data-toggle="collapse" data-target="#navbarSupportedContent"
                        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="ti-more"></i>
                    </a>
                </div>
                <!-- ============================================================== -->
                <!-- End Logo -->
                <!-- ============================================================== -->
                <div class="navbar-collapse collapse" id="navbarSupportedContent" data-navbarbg="skin6">
                    <!-- ============================================================== -->
                    <!-- toggle and nav items -->
                    <!-- ============================================================== -->
                    <ul class="navbar-nav float-left mr-auto">
                       
              
						
                        	<?php
echo "<h4><font color=#330066>Hello &nbsp;".$_SESSION['u_name'];"</h4></font>"
?>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 <?php 
if(isset($_GET['error']))
{
	$error=$_GET['error'];
	echo "<font color=red >".$error."</font>";
	
}
?> 
                    </ul>
	
                    <!-- ============================================================== -->
                    <!-- Right side toggle and nav items -->
                    <!-- ============================================================== -->
                    <ul class="navbar-nav float-right">
                        <!-- ============================================================== -->
                        <!-- User profile and search -->
                        <!-- ============================================================== -->
                        <li class="nav-item dropdown">
						
                            <a class="nav-link dropdown-toggle text-muted waves-effect waves-dark pro-pic" href="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						
								<img src=" images/b-arrow.png" alt="user" class="rounded-circle" width="31"></a>
                            <div class="dropdown-menu dropdown-menu-right user-dd animated">
                              
                                <a class="dropdown-item" href="admin_pages-profile.php"><i class="ti-email m-r-5 m-l-5"></i> Change Password</a>
                                <a class="dropdown-item" href="logout.php"><i class="ti-wallet m-r-5 m-l-5"></i> Log out</a>
                            </div>
                        </li>
                        <!-- ============================================================== -->
                        <!-- User profile and search -->
                        <!-- ============================================================== -->
                    </ul>
                </div>
            </nav>
        </header>
        <!-- ============================================================== -->
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <aside class="left-sidebar" data-sidebarbg="skin5">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="index.php" aria-expanded="false">
                                <i class="mdi mdi-av-timer"></i>
                                <span class="hide-menu">Dashboard</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_pages-profile.php" aria-expanded="false">
                                <i class="mdi mdi-account-network"></i>
                                <span class="hide-menu">Profile</span>
                            </a>
                        </li>
                         <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_employee.php" aria-expanded="false">
                                <i class="mdi mdi-face"></i>
                                <span class="hide-menu">Employee</span>
                            </a>
                        </li>
						 <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_attendance.php" aria-expanded="false">
                                <i class="mdi mdi-face"></i>
                                <span class="hide-menu">Attendance</span>
                            </a>
                        </li>
						
						<li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_package_add.php" aria-expanded="false">
                                <i class="mdi mdi-arrange-bring-forward"></i>
                                <span class="hide-menu">Spa Packages</span>
                            </a>
                        </li>
						
						<li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_employee_leave.php" aria-expanded="false">
                                <i class="mdi mdi-alert-outline"></i>
                                <span class="hide-menu">Leave Requests</span></a>
								</li>
							
                      
						<!--	<li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_payment_view.php" aria-expanded="false">
                                <i class="mdi mdi-alert-outline"></i>
                                <span class="hide-menu">Package Sales</span>
								</a></li>-->
								<li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_billing_view.php" aria-expanded="false">
                                <i class="mdi mdi-alert-outline"></i>
                                <span class="hide-menu">Sales</span>
								</a></li>
								
								<li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_cust_feedback.php" aria-expanded="false">
                                <i class="mdi mdi-arrange-bring-forward"></i>
                                <span class="hide-menu">Customer Feedback</span>
                            </a>
                        </li>
                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </aside>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
	
		
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-5 align-self-center">
                        <h4 class="page-title"></h4>
                    </div>
                    <div class="col-7 align-self-center"><h4 class="page-title">Daily Attendance</h4>
                        <div class="d-flex align-items-center justify-content-end">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item">
                                        <a href="index.php">Beauty</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page">Admin</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                    <!-- Column -->
                    <div class="col-lg-4 col-xlg-3 col-md-5">  
                        <div class="card">
                            <div class="card-body"> <!--<h4 class="page-title">Time In</h4>-->
                                <form class="form-horizontal form-material" action="ad_attendance_action.php" method="POST" enctype="multipart/form-data">
                                   
										 
                                    
									 <div class="form-group">
                                        <label class="col-md-12">Date</label>
                                        <div class="col-md-12">
                                            <input type="date" id="theDate"  name="date" class="form-control form-control-line" readonly>
                                        </div>
										</div>
										 <div class="form-group">
                                        <label class="col-md-12">Staff Id</label>
                                        <div class="col-md-12">
                                             <input type="text" id="UserName" pattern="[a-z0-9._%+-]+@(?=gmail.com|hotmail.com)[a-z0-9.-]+\.[a-z]{2,}$" name="s_name"
											 onchange="CheckUserName(this.value)" class="form-control form-control-line" required>
                                       	  
									   </div>
										 
                                    </div>                     
										
                               <div class="form-group">
                                        <label class="col-md-12">Status</label>
                                        <div class="col-md-12">
                                             <input type="radio"   name="s_name" value="Present" >Present &nbsp;&nbsp;&nbsp;
											  <input type="radio" name="gender" value="male" checked>Absent
                                       	  
									   </div>
									   </div>
									
                                 <div class="col-sm-12">
                                            <button class="btn btn-success" name="btn_timeOut">Save</button>
                                        </div>

                                    </div>
									  <label class="col-md-12" id="ErrorSpan"></label>
                                    
                                </form>
                            </div>
                        </div>
						
						<!--
		
						
						<div class="col-lg-8 col-xlg-9 col-md-7">
                        <div class="card">
                            <div class="card-body">  <h4 class="page-title">Time Out</h4>
                                <form class="form-horizontal form-material" action="ad_attendance_action.php" method="POST" enctype="multipart/form-data">
										<div class="form-group">
                                        <label class="col-md-12">Date</label>
                                        <div class="col-md-12">
                                            <input type="date" id="TheDate"  name="date" class="form-control form-control-line" readonly>
                                        </div>
										 <div class="form-group">
                                        <label class="col-md-12">Staff Id</label>
                                        <div class="col-md-12">
                                           <!--<input type="text" id="UserName" name="s_name" class="form-control form-control-line" pattern="[a-z0-9._%+-]+@(?=gmail.com|hotmail.com)[a-z0-9.-]+\.[a-z]{2,}$"  required>
                               
										
									  <select name="s_name" class="form-control form-control-line">
									  <?php while($array=mysql_fetch_array($fetched))
											{
												?>
									   <option value="<?php echo $array['u_id'];?>"> <?php echo $array['u_id'];?></option>
									   <?php
											}
									   ?>
									   </select>
									   </div>
										 
                                    </div>                                   
								   <div class="form-group">
                                        <label for="example-email" class="col-md-12">Time Out</label>
                                        <div class="col-md-12">
                                            <input type="time" id="timeOut" class="form-control form-control-line" name="time_out" readonly>
                                        </div>
                                    </div>
                                    <div class="col-sm-12">
                                            <button  name="btn_timeOut"class="btn btn-success">Save</button>
                                        </div>
                                   

                                    </div>
                                    
                                </form>
                            </div>
                        </div>
                    </div>-->
						
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
           
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
	 <script>
	
var date = new Date();

var day = date.getDate();
var month = date.getMonth() + 1;
var year = date.getFullYear();



if (month < 10) month = "0" + month;
if (day < 10) day = "0" + day;


var today = year + "-" + month + "-" + day;


document.getElementById('theDate').value = today;
document.getElementById('TheDate').value = today;



</script>
	
	<script>
	function CheckUserName(){
    var UserName = document.getElementById('UserName');
    if(UserName.value != "")
    {
        if (window.XMLHttpRequest)
        {// code for IE7+, Firefox, Chrome, Opera, Safari
          xmlhttp=new XMLHttpRequest();
        }
        else
        {// code for IE6, IE5
          xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange=function()
        {
          if (xmlhttp.readyState==4 && xmlhttp.status==200)
            {
                var value = xmlhttp.responseText;
                if(value == 0)
                {
                    document.getElementById('ErrorSpan').innerHTML="No such user";
                    UserName.focus();
                }
                else
                {
                    document.getElementById('ErrorSpan').innerHTML="";
                }
            }
          }
        xmlhttp.open("GET","ad_attendance_action.php?q="+UserName.value,true);
        xmlhttp.send();
    }
}
	
	</script>
	
	
    <script src="../../assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="../../assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="../../assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="../../assets/extra-libs/sparkline/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="../../dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="../../dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="../../dist/js/custom.min.js"></script>
</body>

</html>
<?php
}
	else
		{
			
			header("location:../ltr/navuser.php?error=wrong password");
		}
?>