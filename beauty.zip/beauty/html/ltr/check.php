<?php
session_start();
$conn=@mysql_connect("localhost","root","") or die('unable to connect');

@mysql_select_db("dbvcare",$conn) or die('could not find db');

$q=$_GET["q"];
$sql="select pack_name from tbl_packages where pack_name='".$q."'";
$result = mysql_query($sql);
$rowcount=mysql_num_rows($result);
echo $rowcount;

?>
