<?php
include("../ltr/dbconnect.php");
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
	<link href="css1/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css1/style.css" rel="stylesheet" type="text/css" media="all" />	
    <link href="css3/datetimepicker.css" rel="stylesheet" type="text/css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ" crossorigin="anonymous"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.22.0/moment-with-locales.min.js"></script>
    <script type="text/javascript" src="js3/datetimepicker.js"></script>
    <link href="https://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
	
    <style>
        body{ background-color: beige; direction: ltr; font-family: 'Roboto';}
        h1 { margin-top: 150px; text-align: center; }
    </style>
    <script type="text/javascript">
    $(document).ready( function () {
        $('#picker').dateTimePicker();
        $('#picker-no-time').dateTimePicker({ showTime: false, dateFormat: 'DD/MM/YYYY'});
    })
    </script>
    <title>Beauty</title>
</head>
<body>

 <div class="collapse navbar-collapse" id="bs-megadropdown-tabs">
<ul class="nav navbar-nav nav_1">
           <li><a class="color" href="navuser.php">Home</a></li>
            		
			<li><a class="color3" href="product.php">Packages</a></li>
			 <li><a class="color5" href="user_booking_availablity.php"> Book Now</a></li>
          
			<li><a class="color5" href="user_profile.php">Profile</a></li>
			
        </ul>
		
    <h1>Select A Date</h1>
	<form action="user_date_action.php" method="POST">
	<div style="width: 250px; margin: 50px auto;">

		<div  name="dateSelect" id="picker-no-time" onChange = "do()">
		<script>
		function do(){
		alert("sjhjsdgf");	
		};
		
		</script>
	<!--<input type="date"  name="dateSelect" 	>
	--></div>
    <input type="hidden" name="result2" id="result2" value="" />
	<input type="submit" name="submit" id="submit"value="submit">
</div>
</form>



</div>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-36251023-1']);
  _gaq.push(['_setDomainName', 'jqueryscript.net']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

  $('#submit').on('click', function(){
    /*this is where you'll place your ajax call*/
	
	var data =$('#picker-no-time').html();

$.ajax({
    type: 'GET',
    url: "user_date_action.php",
    data: data
})
});
  
  
</script>
</body>
</html>
