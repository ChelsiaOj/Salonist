<?php
include("../ltr/dbconnect.php");
session_start();
$u_id=$_SESSION['u_id'];
$u_pass=$_SESSION['u_pass'];
$u_type=$_SESSION['u_type'];
$sql="select * from tbl_login where u_id='$u_id'  and u_password='$u_pass' ";
$result=mysql_query($sql,$conn);
$row1=mysql_fetch_array($result);
$rowcount=mysql_num_rows($result);
$sql1="select * from tbl_u_detail where u_id='$u_id' ";
$result1=mysql_query($sql1,$conn);
$row=mysql_fetch_array($result1);
if($rowcount==1 && $u_type=="Employee")
{
?>



<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="../../assets/images/favicon.png">
    <title>beauty</title>
    <!-- Custom CSS -->
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" property="" />
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
	<link rel="stylesheet" href="css/lightbox.css">
	<link href="css/fontawesome-all.css" rel="stylesheet">
    <link href="../../dist/css/style.min.css" rel="stylesheet">
    
	
	<style>
	
	.pagination {
  display: inline-block;
}

.pagination a {
  color: black;
  float: left;
  padding: 8px 16px;
  text-decoration: none;
  border: 1px solid #ddd;
}

.pagination a.active {
  background-color: #4CAF50;
  color: white;
  border: 1px solid #4CAF50;
}

.pagination a:hover:not(.active) {background-color: #ddd;}

.pagination a:first-child {
  border-top-left-radius: 5px;
  border-bottom-left-radius: 5px;
}

.pagination a:last-child {
  border-top-right-radius: 5px;
  border-bottom-right-radius: 5px;
}

	</style>
	
</head>

<body>
  
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper" data-navbarbg="skin6" data-theme="light" data-layout="vertical" data-sidebartype="full" data-boxed-layout="full">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <header class="topbar" data-navbarbg="skin6">
            <nav class="navbar top-navbar navbar-expand-md navbar-light">
                <div class="navbar-header" data-logobg="skin5">
                    <!-- This is for the sidebar toggle which is visible on mobile only -->
                    <a class="nav-toggler waves-effect waves-light d-block d-md-none" href="javascript:void(0)">
                        <i class="ti-menu ti-close"></i>
                    </a>
                    <!-- ============================================================== -->
                    <!-- Logo -->
                    <!-- ============================================================== -->
					<div class="navbar-brand">
					<h1 class="logo">
					<a class="navbar-brand" href="emp_home.php">
						<i class="fab fa-viadeo"></i>Beauty</a>
				</h1>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
				    aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
                
                    </div>
                    <!-- ============================================================== -->
                    <!-- End Logo -->
                    <!-- ============================================================== -->
                    <!-- ============================================================== -->
                    <!-- Toggle which is visible on mobile only -->
                    <!-- ============================================================== -->
                    <a class="topbartoggler d-block d-md-none waves-effect waves-light" href="javascript:void(0)" data-toggle="collapse" data-target="#navbarSupportedContent"
                        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="ti-more"></i>
                    </a>
                </div>
                <!-- ============================================================== -->
                <!-- End Logo -->
                <!-- ============================================================== -->
                <div class="navbar-collapse collapse" id="navbarSupportedContent" data-navbarbg="skin6">
                    <!-- ============================================================== -->
                    <!-- toggle and nav items -->
                    <!-- ============================================================== -->
					
                    <ul class="navbar-nav float-left mr-auto">
					<?php
echo "<h4><font color=#330066>Hello &nbsp;".$_SESSION['u_name'];"</h4></font>"
?>
                        <!-- ============================================================== -->
                        <!-- Search -->
                        <!-- ============================================================== -->
              <!--  <div> <li class="nav-item search-box">
                            <a class="nav-link waves-effect waves-dark" href="javascript:void(0)">
                                <div class="d-flex align-items-center">
                                    <i class="mdi mdi-magnify font-20 mr-1"></i>
                                    <div class="ml-1 d-none d-sm-block">
                                        <span>Search</span>
                                    </div>
                                </div>
                            </a>
                            <form class="app-search position-absolute">
                                <input type="text" class="form-control" placeholder="Search &amp; enter">
                                <a class="srh-btn">
                                    <i class="ti-close"></i>
                                </a>
                            </form>
                        </li></div>-->
                    </ul>
                    <!-- ============================================================== -->
                    <!-- Right side toggle and nav items -->
                    <!-- ============================================================== -->
					
                    <ul class="navbar-nav float-right"> 

                        <!-- ============================================================== -->
                        <!-- User profile and search -->
                        <!-- ============================================================== -->
                       <?php $image= $row['photo'];
								?>
                            <a class="nav-link dropdown-toggle text-muted waves-effect waves-dark pro-pic" href="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
							<?php echo '
								<img src=" ../uploads/'.$image.'" alt="user" class="rounded-circle" width="31"></a>';?>
                            <div class="dropdown-menu dropdown-menu-right user-dd animated">
                                <a class="dropdown-item" href="emp_pages-profile.php"><i class="ti-email m-r-5 m-l-5"></i> Change Password</a>
                                <a class="dropdown-item" href="logout.php"><i class="ti-wallet m-r-5 m-l-5"></i> Log out</a>
                            </div>
                        </li>
                        <!-- ============================================================== -->
                        <!-- User profile and search -->
                        <!-- ============================================================== -->
                    </ul>
                </div>
            </nav>
        </header>
        <!-- ============================================================== -->
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <aside class="left-sidebar" data-sidebarbg="skin5">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                                               <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="emp_home.php" aria-expanded="false">
                                <i class="mdi mdi-av-timer"></i>
                                <span class="hide-menu">Home</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="emp_pages-profile.php" aria-expanded="false">
                                <i class="mdi mdi-account-network"></i>
                                <span class="hide-menu">Profile</span>
                            </a>
                        </li>
                         
                        
                       <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="emp_counter.php" aria-expanded="false">
                               <i class="mdi mdi-border-none"></i>
                                <span class="hide-menu">Bookings</span>
                            </a>
                        </li>
						
						<li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="emp_customer.php" aria-expanded="false">
                                <i class="mdi mdi-face"></i>
                                <span class="hide-menu">Customers</span>
                            </a>
                        </li>
						
							<li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="emp_leave.php" aria-expanded="false">
                                <i class="mdi mdi-border-none"></i>
                                <span class="hide-menu">Apply Leave </span>
                            </a>
                        </li>
                      
						<li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="emp_billing.php" aria-expanded="false">
                                <i class="mdi mdi-border-none"></i>
                                <span class="hide-menu">Billing</span></a></li>
								
                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </aside>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-5 align-self-center">
                        <h4 class="page-title">Customer Details</h4>
                    </div>
                    <div class="col-7 align-self-center">
					<!--<form action="emp_customer.php" method="GET">
					<input type="email" placeholder="Search customer id" pattern="[a-z0-9._%+-]+@(?=gmail.com|hotmail.com)[a-z0-9.-]+\.[a-z]{2,}$" name="search_name" required>
					 <button type="submit" name="btnsearch"><i class="fa fa-search"></i></button>
					 </form>-->
                        <div class="d-flex align-items-center justify-content-end">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item">
                                        <a href="emp_home.php">Home</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page"> Staff</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
				
				
				
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title"> </h4>
								
								<?php
if(isset($_GET['btnsearch']))
{
	
$name=$_GET['search_name'];	
$query2="select * from tbl_login where u_id='$name'";
$set2=mysql_query("$query2",$conn);
$rowcount2=mysql_num_rows($set2);
if($rowcount2!=0)
{
	$query1="select * from tbl_cust_packages where cust_id='$name'";
$set=mysql_query("$query1",$conn);
$rowcount=mysql_num_rows($set);
if($rowcount!=0){
while($value1=mysql_fetch_array($set))
{
$package=$value1['package'];
	$date=$value1['date'];
	$amount=$value1['price'];
	
	echo "<table class='table'>
	<thead class='thead-light'>
	<tr>
	<th>Packages</th>
	<th>Date</th>
	<th>Amount</th></tr>
	</thead>
	<tbody>
	<tr><td>$package</td><td>$date</td><td>$amount</td></tr></tbody>";
	echo "</table>";
	
}
}
elseif($rowcount==0){
	
	echo "<p>No Spa services untill now!</p>";
}	
}
else{
	
	echo "<h4><font color='red'>No such customer</font></h4>";
}
}
?>
					<br><br>			<!--
                                <h6 class="card-subtitle">you can use any icon with class of <code class="m-r-10">mid mid-</code>name of icon</h6>
                                <div class="material-icon-list-demo">
                                    <div class="row icons" id="icons">-->
									

<table  class="table"><tr>
<thead class="thead-light">
<th>Name</th><th>Status</th>
</thead>
</tr>
<?php
$record_per_page = 2;
//$page = '';
if(isset($_GET["page"]))
{
 $page = $_GET["page"];
}
else
{
 $page = 1;
}

$start_from = ($page-1)*$record_per_page;
				  

$next="select * from tbl_u_detail where u_type='2' LIMIT $start_from, $record_per_page";
$see=mysql_query($next,$conn);

while($value=mysql_fetch_array($see))
{
	$dbmail=$value['u_id'];
$dbname=$value['Fname'];
$dblname=$value['Lname'];
$status=$value['u_status'];
if($status==1)
			{
				$sname="Block";
			}
elseif($status==0) 
			{
				$sname="Unblock";
			}
			






echo "<form action='emp_cust_block.php' value='GET'>";
$tmp="<input type='submit' value='$sname' name='btnstatus'>";
echo "
<tr>
<td> $dbname &nbsp;$dblname
 <td>$tmp</td></tr>";
 echo"<input type='hidden' value='$dbmail' name='u_id'>";
 
 echo"</form>";

}	
echo "</table>";
echo "</center>";

 ?>
 




</table>
</form>

<div class="pagination" align="center">
    <br />
    <?php
    $page_query = "SELECT count(details_id) FROM tbl_u_detail where u_type='2'";
    $page_result = mysql_query($page_query,$conn);
    $row = mysql_fetch_row($page_result);
	$total_records=$row[0];
    $total_pages = ceil($total_records/$record_per_page);
    
    $pagLink = "<div class='pagination'>";  
for ($i=1; $i<=$total_pages; $i++) {  
             $pagLink .= "<a href='emp_customer.php?page=".$i."'>".$i."</a>";  
};  
echo $pagLink . "</div>";  
?>
    
    
    </div>
             
                    
 </div>
 
 
				</div>
		</div>
		<!-- start-->
		
        
    <script src="../../assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="../../assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="../../assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="../../assets/extra-libs/sparkline/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="../../dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="../../dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="../../dist/js/custom.min.js"></script>
</body>

</html>
<?php
}
	else
		{
			
			header("location:../ltr/navuser.php?error=wrong password");
		}
?>