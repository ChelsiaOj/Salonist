<?php
include("../ltr/dbconnect.php");
session_start();

if(isset($_POST['submit']))
{

$sales_month=$_POST['s_month'];
echo date('y/m', strtotime($sales_month));
//$query="select * from tbl_cust_packages";
				
			////mysql_query("$query",$conn);			
							
		
			
				//header("location:../ltr/admin_salary.php?Message=New Position Added");
				

}

?>