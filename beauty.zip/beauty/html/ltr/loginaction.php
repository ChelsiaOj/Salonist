<?php
session_start();
include("../ltr/header.php");
$u_name=$_POST['uname'];
$u_pass=$_POST['upassword'];
$sql="select * from tbl_login where u_id='$u_name'";
$sql1="select * from tbl_u_detail where u_id='$u_name'";

$result=mysql_query($sql,$conn);
$rowcount=mysql_num_rows($result);
$result1=mysql_query($sql1,$conn);
$rowcount1=mysql_num_rows($result1);

if($rowcount!=0 && $rowcount1!=0)
{
	while($row=mysql_fetch_array($result))
	{
		
		while($row1=mysql_fetch_array($result1))
			
		{
			$dbu_name=$row['u_id'];
		$dbu_pass=$row['u_password'];
		
				$name=$row1['Fname'];
				$dbu_type=$row1['u_type'];
				$block=$row1['u_status'];
				
				$_SESSION['u_id']=$dbu_name;
				$_SESSION['u_pass']=$dbu_pass;
				$_SESSION['u_name'] = $name;
				 
			  
		if($dbu_name==$u_name && $dbu_pass==$u_pass && $dbu_type==0)
		{
			$_SESSION['u_type']="admin";
			
		header("location:../ltr/index.php");
		
		}
			
			
		else if($dbu_name==$u_name && $dbu_pass==$u_pass && $dbu_type==2)
			{
			
				if($block==1)
				{
					$_SESSION['log']="In";
				  $_SESSION['u_type']="User";
				 
				 
				header("location:../ltr/product.php");
				}
			else if($block==0)
			{
			header("location:../ltr/navuser.php?error=You are blocked by ADMIN !");
			}
		}
		else if($dbu_name==$u_name && $dbu_pass==$u_pass && $dbu_type==3)
			{
			
				if($block==1)
				{
				
				  $_SESSION['u_type']="Employee";
				 
				header("location:../ltr/emp_home.php");
				}
				else if($block==0)
				{
					header("location:../ltr/navuser.php?error=Access Denied!");
					}
			}
		
		else
		{
			header("location:../ltr/navuser.php?error=Wrong password!");
		}
	
			} }
}

else
{
	header("location:../ltr/navuser.php?error=Wrong username!!");
	
}
?>
