<?php
session_start();
$conn=@mysql_connect("localhost","root","") or die('unable to connect');

@mysql_select_db("dbvcare",$conn) or die('could not find db');
$q=$_GET["q"];
$sql="select * from tbl_u_detail where u_id='".$q."' and u_type=3";
$result = mysql_query($sql,$conn);
$list = mysql_fetch_array($result);
$rate=mysql_num_rows($result);
echo $rate;



if(isset($_POST['btnAddDesig']))
{
$desig=strtoupper($_POST['emp_position']);
$wages=$_POST['emp_wages'];
$query="INSERT INTO `tbl_designation`(`designation`,`rate`) 
							VALUES('$desig','$wages')";
				
			mysql_query("$query",$conn);			
							
		
			
				header("location:../ltr/admin_employee.php?Message=New Position Added");
				

}
if(isset($_POST['wagesubmit']))
{
	 $desig_id=$_POST['emp_position'];


$d_rate=$_POST['emp_rate'];
	//echo  $desig_id;
	//echo $d_rate;
	$query1="UPDATE `tbl_designation` SET `rate`='$d_rate' WHERE `designation`='$desig_id'";

				
			mysql_query("$query1",$conn);
			header("location:../ltr/admin_employee.php?Message=Wages updated");
}

if(isset($_POST['btnAdvPay']))
{
	 $emp_id=$_POST['adPay_id'];
	  $adv_date=$_POST['adPay_date'];


$adv_amount=$_POST['adPay_amount'];
	
	$query1="insert into tbl_cashadvance(`emp_id`,`amount`,`date`) values('$emp_id','$adv_amount','$adv_date')  ";

				
			mysql_query("$query1",$conn);
			header("location:../ltr/admin_salary.php");
}

if(isset($_POST['btnDelete']))
{
	 $c_id=$_POST['hid_id'];
	  
	$query1="delete * from tbl_cashadvance where cash_id='$c_id'  ";

				
			mysql_query("$query1",$conn);
			header("location:../ltr/admin_employee.php");
}


?>