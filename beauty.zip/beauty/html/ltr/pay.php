<?php

session_start();
$conn=@mysql_connect("localhost","root","") or die('unable to connect');

@mysql_select_db("dbvcare",$conn) or die('could not find db');

if(isset($_POST['submit']))
{
	//$amt=$_POST['total_amount']	
	$card_no=$_POST['card_no'];
	$holdername=$_POST['holdername'];
	$month=$_POST['month'];
	$year=$_POST['year'];
	$cvv=$_POST['cvv'];
	$amount=2000;
	$s_id=$_POST['sid'];
	//echo $amount;
	
	$a=mysql_query("SELECT  * FROM tbl_paycard_details WHERE  `pay_card_no`=$card_no AND `pay_expiry_month`=$month AND `pay_expiry_year`=$year AND `pay_holder_name`=$holdername AND `pay_card_cvv`=$cvv",$conn);
   		
	if($a=NULL){
		echo "<script>alert('Wrong Card Details..!');window.location.href='../ltr/user_booking_availablity.php';</script>";
	}
	else
	{
	   $b=mysql_query("SELECT * FROM tbl_paycard_details WHERE  `pay_card_no`=$card_no ",$conn);
       
	   while($row10=mysql_fetch_array($b))
	   {
	
		$balance = $row10['pay_balance'];
		$paycard_detail_id = $row10['paycard_detail_id'];
			
			
			
				echo $res=mysql_query("UPDATE `tbl_cust_packages` SET price_status=1 WHERE id='$s_id'",$conn);
				$cur_balance=$balance-$amount;
				
				$rest=mysql_query("UPDATE `tbl_paycard_details` SET pay_balance=$cur_balance WHERE paycard_detail_id=$paycard_detail_id ",$conn);
				
				$b=mysql_query("SELECT * FROM tbl_paycard_details WHERE  paycard_detail_id=2 ",$conn);
                 while($row102=mysql_fetch_array($b))
				{
					$bal = $row102['pay_balance'];
					$pay_id = $row102['paycard_detail_id'];
					$c_balance=$bal+$amount;
					$reslt=mysql_query("UPDATE `tbl_paycard_details` SET pay_balance=$c_balance WHERE paycard_detail_id=$pay_id ",$conn);
				}
			    //$result10=mysqli_query($con,"INSERT INTO `tbl_payment`(`pay_types`,`card_no`, `holder_name`) VALUES ('debit card','$card_no','$holdername')");
				echo "<script>alert('Payment Done Successfully..!');window.location.href='../ltr/product.php';</script>";
	
			
		}
	}
	
}
?>