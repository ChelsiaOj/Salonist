<?php
session_start();

$u_pass=$_SESSION['u_pass'];

$conn=@mysql_connect("localhost","root","") or die('unable to connect');
@mysql_select_db("dbvcare",$conn) or die('could not find db');

$q=$_GET["q"];

$sql="select * from tbl_u_detail where u_id='".$q."' and u_type='3'";
$result = mysql_query($sql);
$rowcount=mysql_num_rows($result);
echo $rowcount;


if(isset($_POST['btnTime']))
{
$staff_id=$_POST['s_name'];
$att_date=$_POST['date'];
$att_section=$_POST['attn_section'];
$att_status=$_POST['status'];

//echo $att_section;
$query="INSERT INTO `tbl_attendance`( `staff_id`, `date`, `attn_section`,`status`) VALUES ('$staff_id','$att_date','$att_section','$att_status')";
mysql_query("$query",$conn);

header("location:../ltr/index.php?Message=Okay");
}
else
{
	
header("location:../ltr/index.php?Message=Please enter values");	
}

?>
