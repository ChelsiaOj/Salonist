<?php_egg_logo_guid$conn=@mysql_connect("localhost","root","") or die('unable to connect');
@mysql_select_db("dbvcare",$conn) or die('could not find db');
session_start();
if(isset($_GET['btnsearch']))
{
	
$name=$_GET['search_name'];	
	$query1= mysql_query("select * from tbl_cust_packages where cust_id=$name");
$set=mysql_query("$query1",$conn);
while($value=mysql_fetch_array($set))
{
$package=$value['package'];
	$date=$value['date'];
	echo "<table class=''>
	<tr>
	<th>Packages</th>
	<th>Date</th></tr>
	
}
	
}




?>