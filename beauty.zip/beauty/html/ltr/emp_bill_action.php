<?php
session_start();
$conn=@mysql_connect("localhost","root","") or die('unable to connect');

@mysql_select_db("dbvcare",$conn) or die('could not find db');
if(isset($_POST['btnsave']))
{
	$emp_id=$_SESSION['u_id'];
$package=$_POST['pack_name'];
$c_id=$_POST['pack_customer'];
$date=$_POST['pack_date'];
$sql="select * from tbl_packages where pack_name='$package'";
$result1=mysql_query("$sql",$conn);
while($value=mysql_fetch_array($result1))
{
	$price=$value['pack_price'];
$stnt="select * from tbl_login where u_id='$c_id'";
$result=mysql_query("$stnt",$conn);
$rowcount=mysql_num_rows($result);

if($rowcount!=0)
{
$query="insert into `tbl_cust_packages`(`cust_id`,`package`,`price`,`price_status`,`date`,`emp_attend`,`booking_status`) values('$c_id','$package','$price','paid','$date','$emp_id','1')";
mysql_query("$query",$conn);



	header("location:../ltr/emp_billing.php?alert=Added!");
		
}		elseif($rowcount==0){
	header("location:../ltr/emp_billing.php?alert=no user with entered id!");
	
}	
}
}

else
{
	header("location:../ltr/emp_billing.php?error=click pay!");
}


?>



 
