<?php
$conn=@mysql_connect("localhost","root","") or die('unable to connect');
//echo "connected"; 
@mysql_select_db("dbvcare",$conn) or die('could not find db');

$name=$_POST['cust_name'];
$subject=$_POST['subject'];
$message=$_POST['message'];
$phone=$_POST['cust_phone'];
$email=$_POST['cust_email'];

$query="INSERT INTO `tbl_customer_contact`(`e_mail`, `cust_name`,`subject`, `phone`,`message`,`status`) VALUES('$email','$name','$subject','$phone','$message','pending')";
$result=mysql_query("$query",$conn);

	header("location:../ltr/navuser.php");


?>