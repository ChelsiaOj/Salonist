<?php

$conn=@mysql_connect("localhost","root","") or die('unable to connect');
@mysql_select_db("dbvcare",$conn) or die('could not find db');
session_start();

$Fname=$_POST['admin_Fname'];
$Lname=$_POST['admin_Lname'];
$email=$_POST['admin_mail'];
$area=$_POST['admin_area'];
$city=$_POST['admin_city'];
$pin=$_POST['admin_pincode'];
$dist=$_POST['admin_dist'];
$state=$_POST['admin_state'];
$phone=$_POST['admin_phone'];
$query="update tbl_u_detail set `u_id`='$email',`Fname`='$Fname',`Lname`='$Lname',`phone`='$phone' where `u_id`='".$_SESSION['u_id']."'";
mysql_query("$query",$conn);
$_SESSION['u_name'] = $Fname;

$query1="update tbl_address set `area`='$area',`city`='$city',`pincode`='$pin',`district`='$dist',`state`='$state' where `u_id`='".$_SESSION['u_id']."'";
mysql_query("$query1",$conn);
$query2="update tbl_login set `u_id`='$email' where`u_id`='".$_SESSION['u_id']."'";
mysql_query("$query2",$conn);
$_SESSION['u_id'] = $email;
	header("location:../ltr/admin_pages-profile.php");
	
	

?>
