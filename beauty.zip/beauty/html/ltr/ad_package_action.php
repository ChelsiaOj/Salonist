<?php
session_start();
$conn=@mysql_connect("localhost","root","") or die('unable to connect');

@mysql_select_db("dbvcare",$conn) or die('could not find db');
if(isset($_POST['btnAdd']))
{

$p_name=strtoupper($_POST['pack_name']);
$description=$_POST['pack_desc'];
$p_price=$_POST['pack_price'];
//$p_time=$_POST['pack_time'];

$p_image=$_FILES['pack_image']['name'];

if(move_uploaded_file($_FILES['pack_image']['tmp_name'],"../uploads/".$p_image))

{
					
$query="INSERT INTO `tbl_packages`(`pack_name`,`description`,`pack_price`,`pack_image`) 
							VALUES('$p_name','$description','$p_price','$p_image')";
				
			mysql_query("$query",$conn);			
							
		echo "<script>
alert('New service added');
window.location.href='../ltr/admin_package_add.php';
</script>";
			
				//header("location:../ltr/admin_package_add.php?Message=Package Added");
				
				}
				//else
				//{//
					//header("location:../ltr/admin_package_add.php?Message=Package exists.Add another ");
				//}//
				
}

 
if(isset($_POST['btnEdit']))
{
	
	 $pname=$_POST['hid_name'];

$descript=$_POST['pro_desc'];
$p_price=$_POST['pro_price'];
//echo $p_price;
//echo $descript;
//echo $description;
//echo $pname;
			
		$query1="UPDATE `tbl_packages` SET `description`='$descript',`pack_price`='$p_price' WHERE `pack_name`='$pname'";

				
			mysql_query("$query1",$conn);
			echo "<script>
alert('Values updated');
window.location.href='../ltr/admin_package_add.php';
</script>";
			
			//header("location:../ltr/admin_package_add.php");
			}
	

				  


 if(isset($_POST['btnDelete']))
 {
	 // $name=$_POST['packName'];
	 // $desc=$_POST['packDesc'];
	 $name=$_POST['hid_name'];
	  //echo $name;
   $stmt1="DELETE FROM `tbl_packages` WHERE `pack_name`='$name'";
	mysql_query("$stmt1",$conn);
			echo "<script>
alert('Value deleted');
window.location.href='../ltr/admin_package_add.php';
</script>";
	//echo "<script>alert('service deleted');</script>";
	//header("location:../ltr/admin_package_add.php");
			}
  

	
?>
