<?php
session_start();
$conn=@mysql_connect("localhost","root","") or die('unable to connect');

@mysql_select_db("dbvcare",$conn) or die('could not find db');
if(isset($_GET['u_id']))
{
	$uid=$_GET['u_id'];
	$status=$_GET['btnstatus'];
	if($status=='Block')
	{
			
			
			$sql1="update tbl_u_detail set u_status=0 where u_id='$uid'";
			$result1=mysql_query($sql1,$conn);
			
			
			 
			header("location:../ltr/emp_customer.php");
	}
else if($status=='Unblock')
	{
		
			
			$stmt="update tbl_u_detail set u_status=1 where u_id='$uid'";
			$resm=mysql_query($stmt,$conn);
			 
			header("location:../ltr/emp_customer.php");
	}
		
}

?>