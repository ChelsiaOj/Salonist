<?php
session_start();

$u_pass=$_SESSION['u_pass'];

$conn=@mysql_connect("localhost","root","") or die('unable to connect');
 
@mysql_select_db("dbvcare",$conn) or die('could not find db');

$current_pwd=$_POST['current_pwd'];
$password=$_POST['confirm_pwd'];
$photo=$_POST['admin_image'];
if($current_pwd!=$u_pass)
{
	header("location:../ltr/user_profile.php?error=current password incorrect!");
}
else{
$query="update `tbl_login` set `u_password`='$password' where `u_id`='".$_SESSION['u_id']."'";
mysql_query("$query",$conn);
$_SESSION['u_pass'] = $password;

	header("location:../ltr/user_profile.php");
}

	

?>
