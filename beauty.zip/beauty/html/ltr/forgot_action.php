<?php
session_start();
include("../ltr/header.php");
$u_mail=$_POST['mail'];
//$u_question=$_POST['security_q'];
//$u_ans=$_POST['answer'];
$sql="select * from tbl_login where u_id='$u_mail'";
$result=mysql_query($sql,$conn);
$rowcount=mysql_num_rows($result);
if($rowcount!=0)
{
$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%&*_";
$password = substr( str_shuffle( $chars ), 0, 8 );
$query = mysql_query("UPDATE tbl_login SET u_password='$password' WHERE u_id='$u_mail'");
$set1=mysql_query("$query",$conn);
 require 'PHPMailer-master/PHPMailerAutoload.php';

$mail = new PHPMailer();

  //Enable SMTP debugging.
  $mail->SMTPDebug = 1;
  //Set PHPMailer to use SMTP.
  $mail->isSMTP();
  //Set SMTP host name
  $mail->Host = "smtp.gmail.com";
  $mail->SMTPOptions = array(
                    'ssl' => array(
                        'verify_peer' => false,
                        'verify_peer_name' => false,
                        'allow_self_signed' => true
                    )
                );
  //Set this to true if SMTP host requires authentication to send email
  $mail->SMTPAuth = TRUE;
  //Provide username and password
  $mail->Username = "chelsiaoj96@gmail.com";
  $mail->Password = "ammuoj170";
  //If SMTP requires TLS encryption then set it
  $mail->SMTPSecure = "tls";
  $mail->Port = 587;
  

$mail->addAddress($u_mail);

  $mail->isHTML(true);

  $mail->Subject = "Beauty-Forgot Password OTP";
  $mail->Body = "<i>Use your registered mail and following OTP to login your account.Dont disclose the OTP</i>".$password;
  $mail->AltBody = "";
  if(!$mail->send())
   {
      echo "<script>alert('Mail not send. Please check your connection');window.location='forgot_password.php';</script>";
   echo "Mailer Error: " . $mail->ErrorInfo;
   //header("location:../ltr/forgot_password.php?Message=OTP not send");
  }
  else
  {
	  //header("location:../ltr/navuser.php?Message=OTP sent to your mail");
      echo "<script>alert('OTP Sent. Please check your mail');window.location='navuser.php';</script>";
   echo "Message has been sent successfully";
  }
	


}
	else{
		header("location:../ltr/forgot_password.php?error=Entered mail not found. Please Check.");
	
	}


?>