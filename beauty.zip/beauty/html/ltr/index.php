<?php
include("../ltr/dbconnect.php");
session_start();
$u_id=$_SESSION['u_id'];
$u_pass=$_SESSION['u_pass'];
$u_type=$_SESSION['u_type'];
$sql="select * from tbl_login where u_id='$u_id'  and u_password='$u_pass' ";
$result=mysql_query($sql,$conn);
$rowcount=mysql_num_rows($result);
$sql1="select * from tbl_u_detail where u_id='$u_id' ";
$result1=mysql_query($sql1,$conn);
$row=mysql_fetch_array($result1);
if($rowcount==1 && $u_type=="admin")
{
?>


<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
	
	
	
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="../../assets/images/favicon.png">
    <title>Beauty</title>
	<!--  new-add-->
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" property="" />
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
	<link rel="stylesheet" href="css/lightbox.css">
	<link href="css/fontawesome-all.css" rel="stylesheet">
	<!--  new-add->
    <!-- Custom CSS -->
    <link href="../../assets/libs/chartist/dist/chartist.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="../../dist/css/style.min.css" rel="stylesheet">
    
</head>

<body>
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper" data-navbarbg="skin6" data-theme="light" data-layout="vertical" data-sidebartype="full" data-boxed-layout="full">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <header class="topbar" data-navbarbg="skin6">
            <nav class="navbar top-navbar navbar-expand-md navbar-light">
                <div class="navbar-header" data-logobg="skin5">
                    <!-- This is for the sidebar toggle which is visible on mobile only -->
                    <a class="nav-toggler waves-effect waves-light d-block d-md-none" href="javascript:void(0)">
                        <i class="ti-menu ti-close"></i>
                    </a>
                    <!-- ============================================================== -->
                    <!-- Logo -->
                    <!-- ============================================================== -->
                  <!--newly added-->  
				  <div class="navbar-brand">
					<!--<nav class="navbar navbar-expand-lg navbar-light bg-light top-header">-->
				<h1 class="logo">
					<a class="navbar-brand" href="index.php">
						<i class="fab fa-viadeo"></i>Beauty</a>
				</h1>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
				    aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
                        <!--<a href="index.php" class="logo">
                            <!-- Logo icon -->
                          <!--  <b class="logo-icon">
                                <!--You can put here icon as well // <i class="wi wi-sunset"></i> //
                                <!-- Dark Logo icon 
                                <img src="../../assets/images/logo-icon.png" alt="homepage" class="dark-logo" />
                                <!-- Light Logo icon 
                                <img src="../../assets/images/logo-light-icon.png" alt="homepage" class="light-logo" />
                            </b>
                            <!--End Logo icon -->
                            <!-- Logo text -->
                            <!--<span class="logo-text">
                                <!-- dark Logo text 
                                <img src="../../assets/images/logo-text.png" alt="homepage" class="dark-logo" />
                                <!-- Light Logo text 
                                <img src="../../assets/images/logo-light-text.png" class="light-logo" alt="homepage" />
                            </span>
                        </a> -->
                    </div>
                    <!-- ============================================================== -->
                    <!-- End Logo -->
                    <!-- ============================================================== -->
                    <!-- ============================================================== -->
                    <!-- Toggle which is visible on mobile only -->
                    <!-- ============================================================== -->
                    <a class="topbartoggler d-block d-md-none waves-effect waves-light" href="javascript:void(0)" data-toggle="collapse" data-target="#navbarSupportedContent"
                        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="ti-more"></i>
                    </a>
                </div>
                <!-- ============================================================== -->
                <!-- End Logo -->
                <!-- ============================================================== -->
                <div class="navbar-collapse collapse" id="navbarSupportedContent" data-navbarbg="skin6">
                    <!-- ============================================================== -->
                    <!-- toggle and nav items -->
                    <!-- ============================================================== -->
                    <ul class="navbar-nav float-left mr-auto">
                        <!-- ============================================================== -->
                        <!-- Search -->
                        <!-- ============================================================== -->
                      <!--  <li class="nav-item search-box">
                            <a class="nav-link waves-effect waves-dark" href="javascript:void(0)">
                                <div class="d-flex align-items-center">
                                    <i class="mdi mdi-magnify font-20 mr-1"></i>
                                    <div class="ml-1 d-none d-sm-block">
                                        <span>Search</span>
                                    </div>
                                </div>
                            </a>
                            <form class="app-search position-absolute">
                                <input type="text" class="form-control" placeholder="Search &amp; enter">
                                <a class="srh-btn">
                                    <i class="ti-close"></i>
                                </a>
                            </form>
                        </li>-->	<?php
echo "<h4><font color=#330066>Hello &nbsp;".$_SESSION['u_name'];"</h4></font>"
?>
                    </ul>
                    <!-- ============================================================== -->
                    <!-- Right side toggle and nav items -->
                    <!-- ============================================================== -->
                    <ul class="navbar-nav float-right">
                        <!-- ============================================================== -->
                        <!-- User profile and search -->
                        <!-- ============================================================== -->
                         <li class="nav-item dropdown">
						
                            <a class="nav-link dropdown-toggle text-muted waves-effect waves-dark pro-pic" href="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
							<img src=" images/b-arrow.png" alt="user" class="rounded-circle" width="31"></a>
                            <div class="dropdown-menu dropdown-menu-right user-dd animated">
                              
                                <a class="dropdown-item" href="admin_pages-profile.php"><i class="ti-email m-r-5 m-l-5"></i> Change Password</a>
                                <a class="dropdown-item" href="logout.php"><i class="ti-wallet m-r-5 m-l-5"></i> Log out</a>
                            </div>
                        </li>
                        <!-- ============================================================== -->
                        <!-- User profile and search -->
                        <!-- ============================================================== -->
                    </ul>
                </div>
            </nav>
        </header>
        <!-- ============================================================== -->
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <aside class="left-sidebar" data-sidebarbg="skin5">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="index.php" aria-expanded="false">
                                <i class="mdi mdi-av-timer"></i>
                                <span class="hide-menu">Dashboard</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_pages-profile.php" aria-expanded="false">
                                <i class="mdi mdi-account-network"></i>
                                <span class="hide-menu">Profile</span>
                            </a>
                        </li>
                         <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_employee.php" aria-expanded="false">
                                <i class="mdi mdi-face"></i>
                                <span class="hide-menu">Employee</span>
                            </a>
                        </li>
						
						<li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_package_add.php" aria-expanded="false">
                                <i class="mdi mdi-arrange-bring-forward"></i>
                                <span class="hide-menu">Salon Services</span>
                            </a>
                        </li>
						
						<li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_employee_leave.php" aria-expanded="false">
                                <i class="mdi mdi-arrange-bring-forward"></i>
                                <span class="hide-menu">Leave Requests</span></a>
								</li>
							
                      
						<!--	<li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_payment_view.php" aria-expanded="false">
                                <i class="mdi mdi-alert-outline"></i>
                                <span class="hide-menu">Package Sales</span>
								</a></li>
								<li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_billing_view.php" aria-expanded="false">
                                <i class="mdi mdi-arrange-bring-forward"></i>
                                <span class="hide-menu">Sales</span>
								</a></li>
								<li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_salary.php" aria-expanded="false">
                                <i class="mdi mdi-arrange-bring-forward"></i>
                                <span class="hide-menu">Salary</span>
								</a></li>
							<!--	
								<li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="admin_cust_feedback.php" aria-expanded="false">
                                <i class="mdi mdi-arrange-bring-forward"></i>
                                <span class="hide-menu">Customer Feedback</span>
                            </a>
                        </li>-->
                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </aside>
        
        <div class="page-wrapper">

            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-5 align-self-center">
                        <h4 class="page-title"></h4>
                    </div>
                    <div class="col-7 align-self-center">
                        <div class="d-flex align-items-center justify-content-end">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item">
                                        <a href="index.php">Beauty</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page">Admin</li>
                                </ol>
                            </nav>
                        </div>
						<?php 
if(isset($_GET['message']))
{
	$error=$_GET['message'];
	echo "<font color=green >".$message."</font>";
	
}
?>
						
                    </div>
                </div>
            </div>
            
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Email campaign chart -->
                <!-- ============================================================== -->
				<div class="row">
				<!--&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-->
				 
				    <!--<div class="col-lg-4 col-xlg-3 col-md-5">  
					 <div class="">
                            <div class="">
							  </div>
                            </div>
							</div>

				   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				   <div class="col-lg-4 col-xlg-3 col-md-5">  
                        <div class="card">
                            <div class="card-body"> <h4 class="page-title"> Daily Attendance</h4>
                                <form class="form-horizontal form-material" action="ad_attendance_action.php" method="POST" enctype="multipart/form-data">
                                   <div class="form-group">
                                        <label class="col-md-12">Date</label>
                                        <div class="col-md-12">
                                            <input type="date" id="theDate"  name="date" class="form-control form-control-line" readonly>
                                        </div>
										</div>
										
										 <div class="form-group">
                                        <label class="col-md-12">Staff Id</label>
                                        <div class="col-md-12">
               <input type="text" id="UserName" pattern="[a-z0-9._%+-]+@(?=gmail.com|hotmail.com)[a-z0-9.-]+\.[a-z]{2,}$" name="s_name"
											onchange="CheckUserName(this.value)" class="form-control form-control-line" required>
                                       	  
									   </div>
										 <span id="ErrorSpan"></span>
										</div>   
										<div class="form-group">
                                        <label class="col-md-12">Section</label>
                                        <div class="col-md-12">
                                            <select name="attn_section" class="form-control form-control-line" required>
											<option value="FN">FN</option>
											<option value="AN">AN</option>
											</select>
                                        </div>
										</div>										
										
										<div class="form-group">
                                        <label class="col-md-12">Status</label>
                                        <div class="col-md-12">
                                             <input type="radio"   name="status" value="present" >Present &nbsp;&nbsp;&nbsp;
											  <input type="radio" name="status" value="absent">Absent
                                       	  
									   </div>
									   </div>
									
										<div class="col-sm-12">
                                            <button class="btn btn-success" name="btnTime">Save</button>
                                        </div>
										</div>
								<label class="col-md-12" id="ErrorSpan"></label>
                                    
                                </form>
                            </div>
                        </div>-->
					
					<div class="col-lg-8 col-xlg-9 col-md-7">
                    <?php
					$stmt="select * from tbl_u_detail";
					$result=mysql_query($stmt,$conn);
					$rowcount=mysql_num_rows($result)-1;
					$stmt1="select * from tbl_u_detail where u_type=2";
					$result1=mysql_query($stmt1,$conn);
					$rowcount1=mysql_num_rows($result1);
					$stmt2="select * from tbl_u_detail where u_type=3";
					$result2=mysql_query($stmt2,$conn);
					$rowcount2=mysql_num_rows($result2);
					?>
                    
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Total Users</h4>
                                <h2 class="font-light"><?php echo $rowcount?> <span class="font-16 text-success font-medium"></span></h2>
                                <div class="m-t-30">
                                    <div class="row text-center">
                                        <div class="col-6 border-right">
                                            <h4 class="m-b-0"><?php echo $rowcount1 ?> </h4>
                                            <span class="font-14 text-muted"> Users</span>
                                        </div>
                                        <div class="col-6">
                                            <h4 class="m-b-0"><?php echo $rowcount2 ?></h4>
                                            <span class="font-14 text-muted">Staff</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                   </div>
						
						
				   
               </div>
				
				
				<div class="row">
                    <div class="col-lg-4 col-xlg-3 col-md-5"> 
                        <div class="card">
                            <br>
							
							<?php
							$result = mysql_query('SELECT SUM(price) AS price_sum FROM tbl_cust_packages'); 
						$row = mysql_fetch_assoc($result); 
						$sum = $row['price_sum'];
							?>
                                <h4 class="card-title">Total Income</h4>
                                <h2 class="font-light">    <span class="font-16 text-success font-medium"></span></h2>
                                <div class="m-t-30">
                                    <div class="row text-center">
                                        <div class="col-6 border-right">
                                            <h4 class="m-b-0"> <?php  echo $sum; ?>   </h4>
                                            <span class="font-14 text-muted"> </span>
                                        </div>
                                       
                                  
                            </div>
                        </div>                         
                                    </div>
									 
                            </div>
							
							<div class="col-lg-4 col-xlg-3 col-md-5"> 
                        <div class="card">
                            <br>
							
							<?php
							
							$result1 = mysql_query('SELECT package, COUNT(package) AS magnitude FROM tbl_cust_packages GROUP BY package ORDER BY magnitude DESC
LIMIT 2'); 
						$row1= mysql_fetch_assoc($result1); 
						$pname=$row1['package'];
						$most = $row1['magnitude'];
							?>
                                <h4 class="card-title">Frequently used Service</h4>
                                <h2 class="font-light">    <span class="font-16 text-success font-medium"></span></h2>
                                <div class="m-t-30">
                                    <div class="row text-center">
                                        <div class="col-6 border-right">
                                            <h4 class="m-b-0"> <?php  echo $pname; ?> </h4>
                                            <span class="font-14 text-muted"> </span>
                                        </div>
                                       
                                  
                            </div>
                        </div>                         
                                    </div>
									 
                            </div>
							
							
                        </div>
				<?php
					
					//$stmt="select * from tbl_products where pro_quantity<10";
					//$result=mysql_query($stmt,$conn);
				////echo "<h4><font color='red'>Attention Needed</font></h4>";
					//echo "<h4><font color='red'>Action Required</font></h4>";
					///echo" <div class='card'>";
					//echo "<table class='table'>";
					//echo "<th>Product Id</th><th>Name</th><th>Type</th><th>Stock</th>";
					//while($value=mysql_fetch_array($result))
								//	{//
										
					//$name=$value['pro_name'];
					//$type=$value['company'];
					//$p_id=$value['pro_id'];
					//$status="running out";
					
					//echo "<tr><td><font color='green'>$p_id</font></td><td>$name</td><td>$type</td><td><font color='red'>$status</fonts></td></tr>";
					
									//}//
									//echo "</table>";
					//echo "</div>";
					
					?>
					
               
               
                <!-- ============================================================== -->
                <!-- Email campaign chart -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Ravenue - page-view-bounce rate -->
                <!-- ============================================================== -->
               
                <!-- ============================================================== -->
                <!-- Ravenue - page-view-bounce rate -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Recent comment and chats -->
                <!-- ============================================================== -->
                
                    <!-- column -->
					<!--<div class="column">
                    <div class="col-lg-6">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Recent Comments</h4>
                            </div>
							
                            <div class="comment-widgets" style="height:430px;">
							
                                <!-- Comment Row 
                                <div class="d-flex flex-row comment-row m-t-0">
								
                                    <div class="p-2">
                                        <img src="../../assets/images/log.png" alt="user" width="30" class="rounded-circle">
                                    </div>
                                    <div class="comment-text w-100">
									
                                        <h6 class="font-medium">?></h6>
                                        <span class="m-b-15 d-block">< echo $mess?> </span>
                                        <div class="comment-footer">
                                            <span class="text-muted float-right"><$mail?></span>
                                           
                                            <span class="action-icons">
                                               
                                                <a href="javascript:void(0)">
                                                    <i class="ti-heart"></i>
                                                </a>
                                            </span>
											
                                        </div>
									
                                    </div>
									
                                </div>
								< 
									}
									?>
                                <!-- Comment Row -->
                               
                                <!-- Comment Row -->
                               
                                <!-- Comment Row -->
                                
                            </div>
                        </div>
                    </div>
                    <!-- column -->
					
					
                  
                </div>
                <!-- ============================================================== -->
                <!-- Recent comment and chats -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
      
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
		 <script>
	
var date = new Date();

var day = date.getDate();
var month = date.getMonth() + 1;
var year = date.getFullYear();



if (month < 10) month = "0" + month;
if (day < 10) day = "0" + day;


var today = year + "-" + month + "-" + day;


document.getElementById('theDate').value = today;
document.getElementById('TheDate').value = today;



</script>
	
	<script>
	function CheckUserName(){
    var UserName = document.getElementById('UserName');
    if(UserName.value != "")
    {
        if (window.XMLHttpRequest)
        {// code for IE7+, Firefox, Chrome, Opera, Safari
          xmlhttp=new XMLHttpRequest();
        }
        else
        {// code for IE6, IE5
          xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange=function()
        {
          if (xmlhttp.readyState==4 && xmlhttp.status==200)
            {
                var value = xmlhttp.responseText;
                if(value == 0)
                {
                    document.getElementById('ErrorSpan').innerHTML="Entered user not found.Please check the id";
					 $('#btnTime').prop('disabled', true)
                    UserName.focus();
                }
                else
                {
                    document.getElementById('ErrorSpan').innerHTML="";
                }
            }
          }
        xmlhttp.open("GET","ad_attendance_action.php?q="+UserName.value,true);
        xmlhttp.send();
    }
}
	
	</script>
	
    <script src="../../assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="../../assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="../../assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="../../assets/extra-libs/sparkline/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="../../dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="../../dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="../../dist/js/custom.min.js"></script>
    <!--This page JavaScript -->
    <!--chartis chart-->
    <script src="../../assets/libs/chartist/dist/chartist.min.js"></script>
    <script src="../../assets/libs/chartist-plugin-tooltips/dist/chartist-plugin-tooltip.min.js"></script>
    <script src="../../dist/js/pages/dashboards/dashboard1.js"></script>
</body>

</html>

<?php
}
	else
		{
			
			header("location:../ltr/navuser.php?error=wrong password");
		}
?>